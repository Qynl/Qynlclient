package com.qynl.client.mixin;

import com.qynl.client.QynlClient;
import com.qynl.client.module.modules.StreamerModeModule;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {
	@Inject(method = "render(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/DeltaTracker;)V", at = @At("TAIL"))
	private void qynlclient$renderHud(class_332 guiGraphics, class_9779 deltaTracker, CallbackInfo ci) {
		// StreamerMode check — if active, render NOTHING on the HUD
		if (StreamerModeModule.shouldHide("any")) return;

		class_310 client = class_310.method_1551();
		if (client.field_1724 != null && client.field_1687 != null && client.field_1755 == null) {
			QynlClient.getInstance().getHudRenderer().render(guiGraphics, client);
		}
	}
}
