package com.qynl.client.hud;

import com.qynl.client.QynlClient;
import com.qynl.client.module.Module;
import com.qynl.client.module.ModuleManager;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;

/**
 * KeybindScreen — the in-game keybind editor.
 * Click a module row, then press the key you want to use. Press
 * Esc / Backspace / Delete to remove the keybind. Changes are saved
 * instantly to the config.
 */
public class KeybindScreen extends class_437 {
	private static final int ROW_HEIGHT = 22;
	private static final int START_Y = 44;

	private final List<Module> rows = new ArrayList<>();
	private Module waitingModule = null;

	public KeybindScreen() {
		super(class_2561.method_43470("QynlClient — Keybinds"));
	}

	@Override
	protected void method_25426() {
		rows.clear();
		waitingModule = null;
		ModuleManager modules = QynlClient.getInstance().getModuleManager();
		int centerX = this.field_22789 / 2;
		int y = START_Y;

		class_7842 hint = new class_7842(
				class_2561.method_43470("Click a module, then press the key. Esc / right-click / Backspace = no key. F-keys, numbers, T and F are kept for the game."),
				this.field_22793);
		hint.method_46421(centerX - 150);
		hint.method_46419(28);
		this.method_37063(hint);

		for (Module module : modules.getModules()) {
			rows.add(module);
			this.method_37063(class_4185.method_46430(class_2561.method_43470(""), b -> startBinding(module))
					.method_46434(centerX - 150, y, 300, 20).method_46431());
			y += ROW_HEIGHT;
		}

		this.method_37063(class_4185.method_46430(class_2561.method_43470("Back"), b -> this.method_25419())
				.method_46434(centerX - 60, y + 8, 120, 20).method_46431());
	}

	private void startBinding(Module module) {
		waitingModule = module;
	}

	private void setBind(Module module, int keyCode) {
		module.setKeyCode(keyCode);
		waitingModule = null;
		QynlClient.getInstance().getModuleManager().saveToConfig();
	}

	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers) {
		if (waitingModule != null) {
			if (keyCode == GLFW.GLFW_KEY_ESCAPE
					|| keyCode == GLFW.GLFW_KEY_BACKSPACE
					|| keyCode == GLFW.GLFW_KEY_DELETE) {
				setBind(waitingModule, -1);
			} else if (keyCode > 0 && !isModifierKey(keyCode) && !isGameCriticalKey(keyCode)) {
				setBind(waitingModule, keyCode);
			}
			return true;
		}
		return super.method_25404(keyCode, scanCode, modifiers);
	}

	private boolean isModifierKey(int keyCode) {
		return keyCode >= GLFW.GLFW_KEY_LEFT_SHIFT && keyCode <= GLFW.GLFW_KEY_LAST;
	}

	/** Only a handful of keys the game absolutely needs stay reserved.
	 *  Everything else (including F-keys and numbers) is available so
	 *  every player can find a key that works for them. */
	private boolean isGameCriticalKey(int keyCode) {
		return keyCode == GLFW.GLFW_KEY_ENTER
				|| keyCode == GLFW.GLFW_KEY_KP_ENTER
				|| keyCode == GLFW.GLFW_KEY_SLASH
				|| keyCode == GLFW.GLFW_KEY_TAB
				|| keyCode == GLFW.GLFW_KEY_F1   // debug / shift-F1 pie chart
				|| keyCode == GLFW.GLFW_KEY_F2;  // always reserved for the game
	}

	@Override
	public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		this.method_25420(guiGraphics, mouseX, mouseY, partialTick);
		guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 12, 0xFFFFFFFF);
		super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

		int centerX = this.field_22789 / 2;
		for (int i = 0; i < rows.size(); i++) {
			Module module = rows.get(i);
			int y = START_Y + i * ROW_HEIGHT;
			guiGraphics.method_51439(this.field_22793, class_2561.method_43470(module.getName()),
					centerX - 142, y + 6, 0xFFFFFFFF, false);
			if (waitingModule == module) {
				guiGraphics.method_27534(this.field_22793,
						class_2561.method_43470("Press a key… (Esc = none)"),
						centerX, y + 6, HudRenderer.ACCENT);
			} else {
				guiGraphics.method_51439(this.field_22793, class_2561.method_43470("[" + module.getKeyLabel() + "]"),
						centerX + 150 - this.field_22793.method_1727("[" + module.getKeyLabel() + "]"), y + 6,
						module.getKeyMapping() != null && module.getKeyMapping().method_1415() ? 0xFF6B7280 : 0xFF9CA3AF,
						false);
			}
		}
	}

	/** Right-clicking a module row removes its keybind (leaves it unbound). */
	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		if (button == 1) {
			int centerX = this.field_22789 / 2;
			for (int i = 0; i < rows.size(); i++) {
				double rowY = START_Y + i * ROW_HEIGHT;
				if (mouseX >= centerX - 150 && mouseX <= centerX + 150
						&& mouseY >= rowY && mouseY <= rowY + 20) {
					setBind(rows.get(i), -1);
					return true;
				}
			}
		}
		return super.method_25402(mouseX, mouseY, button);
	}

	@Override
	public void method_25419() {
		waitingModule = null;
		super.method_25419();
	}

	@Override
	public boolean method_25421() {
		return false;
	}
}
