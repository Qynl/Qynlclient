package com.qynl.client.module;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1109;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

public abstract class Module {
	private final String name;
	private final String description;
	private final Category category;
	private final Map<String, Setting<?>> settings = new LinkedHashMap<>();
	private class_304 keyMapping;
	private String keyLabel = "";
	private int keyCode = -1;
	private boolean keyLabelResolved;
	private boolean enabled;

	public Module(String name, String description, Category category) {
		this.name = name;
		this.description = description;
		this.category = category;
	}

	/** Registers a toggle keybind with the game's Controls screen.
	 *  GLFW is NOT called during construction — the label is resolved
	 *  lazily on first access, well after Minecraft has initialised. */
	protected void bindKey(int keyCode) {
		String keyName = name.toLowerCase().replace(" ", "_");
		keyMapping = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.qynlclient." + keyName,
				class_3675.class_307.field_1668,
				keyCode,
				"category.qynlclient"
		));
		this.keyCode = keyCode;
		// Defer GLFW: keyLabel stays "" until first getKeyLabel() call.
		keyLabelResolved = false;
	}

	/** Changes the toggle key at runtime (used by the in-game keybind editor). */
	public void setKeyCode(int keyCode) {
		if (keyMapping == null) {
			return;
		}
		this.keyCode = keyCode;
		if (keyCode <= 0) {
			keyMapping.method_1422(class_3675.field_16237);
			keyLabel = "None";
			keyLabelResolved = true;
		} else {
			keyMapping.method_1422(class_3675.class_307.field_1668.method_1447(keyCode));
			keyLabelResolved = false; // lazy-resolve on next getKeyLabel()
		}
		// 1.21.1's KeyMapping.setKey() only writes the key field — the static
		// key→mapping lookup (MAP) is NOT rebuilt, so the old key keeps firing
		// the module after an unbind/rebind until the next game restart.
		// Rebuild it and clear any stale pressed state so changes apply now.
		keyMapping.method_23481(false);
		class_304.method_1426();
	}

	public int getKeyCode() {
		return keyCode;
	}

	/**
	 * Returns a human-readable key name.  The first call resolves the name
	 * via GLFW (which is guaranteed to be initialised by that point).
	 * The result is cached so GLFW is only called once per module.
	 */
	public String getKeyLabel() {
		if (!keyLabelResolved) {
			keyLabelResolved = true;
			if (keyCode <= 0) {
				keyLabel = "None";
			} else {
				String glfwName = GLFW.glfwGetKeyName(keyCode, 0);
				keyLabel = glfwName != null ? glfwName.toUpperCase() : "KEY_" + keyCode;
			}
		}
		return keyLabel;
	}

	public boolean handleKey(class_310 client) {
		if (keyMapping != null && keyMapping.method_1436()) {
			toggle();
			return true;
		}
		return false;
	}

	public void toggle() {
		boolean next = !enabled;
		setEnabled(next);
		playToggleSound(next);
	}

	/** Plays a short click so toggling is audible — an accessibility aid. */
	private void playToggleSound(boolean on) {
		class_310 client = class_310.method_1551();
		if (client == null || client.method_1483() == null) {
			return;
		}
		client.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, on ? 1.0F : 0.55F));
	}

	public void setEnabled(boolean enabled) {
		if (this.enabled == enabled) {
			return;
		}
		this.enabled = enabled;
		if (enabled) {
			onEnable();
		} else {
			onDisable();
		}
	}

	public void onEnable() {}
	public void onDisable() {}
	public void onTick(class_310 client) {}

	/** Fired by the central tick when the world reference changes or the
	 *  player dies — the place to drain buffered packets. Runs even while
	 *  the module is disabled, so state never outlives a world. */
	public void onWorldChange(class_310 client) {}

	/** Fired when the world becomes null (disconnect / leaving). */
	public void onDisconnect(class_310 client) {}

	public String getName()        { return name; }
	public String getDescription() { return description; }
	public Category getCategory()  { return category; }
	public class_304 getKeyMapping() { return keyMapping; }
	public boolean isEnabled()     { return enabled; }

	// ── settings ────────────────────────────────────────────────

	protected void addSetting(Setting<?> setting) {
		settings.put(setting.getKey(), setting);
	}

	public Setting<?> getSetting(String key) {
		return settings.get(key);
	}

	public Collection<Setting<?>> getSettings() {
		return settings.values();
	}

	public boolean hasSettings() {
		return !settings.isEmpty();
	}

	public String getStringSetting(String key) {
		Setting<?> s = settings.get(key);
		return s == null ? "" : String.valueOf(s.getValue());
	}

	public double getDoubleSetting(String key) {
		Setting<?> s = settings.get(key);
		return s == null ? 0 : s.asDouble();
	}

	public void applySetting(String key, String value) {
		Setting<?> s = settings.get(key);
		if (s != null) s.setFromString(value);
	}
}