package com.qynl.client.module.modules;

import com.qynl.client.Friends;
import com.qynl.client.QynlClient;
import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import com.qynl.client.util.SilentAim;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import net.minecraft.class_5819;
import org.lwjgl.glfw.GLFW;

/**
 * AimAssist — humanized aim correction while attacking.
 *
 * <p><b>Cubic ease-out glide</b> — accelerates fast when far from target,
 * decelerates smoothly near it. Never snaps.</p>
 *
 * <p><b>Human convergence</b> — near the target, damped settling with
 * residual wobble instead of a perfect lock. A zero-error lock is a
 * textbook ML-anti-cheat signature.</p>
 *
 * <p><b>Mouse-grid (GCD) snap</b> — every correction step is rounded to
 * real mouse-pixel increments at the player's current sensitivity.</p>
 *
 * <p><b>Hard rotation-speed cap</b> — never exceeds ~12°/tick (240°/s).
 * Anything faster is physically impossible for a human.</p>
 *
 * <p><b>Predictive lead</b> — aims at where the target will be next tick
 * based on its current velocity.</p>
 *
 * <p>Three modes: <b>Rotations</b> (camera moves), <b>LockView</b>
 * (crosshair follows target, cleaner), <b>Silent</b> (server sees aimed
 * rotations, player keeps camera control).</p>
 */
public class AimAssistModule extends Module {
    // ── internal aim engine ──
    private final class_5819 r = class_5819.method_43047();
    private class_1297 target;
    private int    reactionTicks;
    private int    overrideTicks;
    private double lastMx, lastMy;
    private double aimYawOff, aimPitchOff;
    private int    wanderTimer;
    private double wanderPhase;
    private double convPhase;

    // runtime cfg
    private double strength;
    private double baseSpeed;
    private int    reactionBase;
    private double aimHeight;
    private boolean predictive;

    public AimAssistModule() {
        super("AimAssist",
              "Humanized aim — cubic ease-out glide, convergence wobble, GCD snap, rotation cap, predictive lead.",
              Category.COMBAT);
        bindKey(GLFW.GLFW_KEY_O);
        addSetting(Setting.options("trigger",  "Trigger",   "OnAttack", "OnAttack", "Always"));
        addSetting(Setting.options("mode",     "Mode",      "Rotations", "Rotations", "LockView", "Silent"));
        addSetting(Setting.range ("strength",  "Strength",  100.0,  25, 200, 5, "%"));
        addSetting(Setting.options("priority", "Priority",  "Crosshair", "Crosshair", "Distance", "Health", "Angle"));
        addSetting(Setting.options("aimPoint", "Aim point", "Body", "Head", "Body", "Feet"));
        addSetting(Setting.range ("fov",       "FOV",       40.0,   8,  90, 2, "\u00b0"));
        addSetting(Setting.range ("range",     "Range",      8.0,   3,  16, 0.5, "b"));
        // Default "Players" — the client is built for friends-server PvP, and
        // "Hostile" (Enemy marker) would find nothing but zombies there.
        addSetting(Setting.options("target",   "Target",    "Players", "Players", "Hostile", "All"));
        addSetting(Setting.range ("reaction",  "Reaction",  150.0, 50, 400, 25, "ms"));
        addSetting(Setting.options("vertLock", "Vert lock",  "Off", "Off", "On"));
        addSetting(Setting.options("autoFire", "Auto-fire",  "Off", "Off", "On"));
    }

    @Override public void onEnable()  { pullCfg(); }
    @Override public void onDisable() { SilentAim.clear(); target = null; }

    private void pullCfg() {
        strength   = getDoubleSetting("strength") / 100.0;
        baseSpeed  = 1.2 + strength * 1.1;
        reactionBase = (int) Math.round(getDoubleSetting("reaction") / 50.0);
        aimHeight  = switch (getStringSetting("aimPoint")) {
            case "Head" -> 0.95; case "Feet" -> 0.12; default -> 0.60; };
        predictive = true;
    }

    // ── tick ────────────────────────────────────────────────────

    @Override public void onTick(class_310 mc) {
        pullCfg();
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        // Trigger: "Always" aims whenever a target is in FOV/range (1.8.9
        // behavior); "OnAttack" only while the attack key is held.
        boolean always = "Always".equals(getStringSetting("trigger"));
        boolean engaged = (always || mc.field_1690.field_1886.method_1434())
                && mc.field_1755 == null && !mc.field_1724.method_7325();
        class_1297 t = engaged ? findTarget(mc) : null;

        // ── update internal state ──
        double mx = mc.field_1729.method_1603(), my = mc.field_1729.method_1604();
        double move = Math.hypot(mx - lastMx, my - lastMy);
        lastMx = mx; lastMy = my;
        if (move > 4.0) overrideTicks = 6;
        else if (overrideTicks > 0) overrideTicks--;

        if (t != target) {
            target = t;
            reactionTicks = t != null ? reactionBase + r.method_43048(4) : 0;
            wanderTimer = 0; convPhase = 0;
            if (t != null) reWander();
        } else if (target != null) {
            if (reactionTicks > 0) reactionTicks--;
            if (--wanderTimer <= 0) { wanderTimer = 4 + r.method_43048(8); reWander(); }
        }

        if (target == null || reactionTicks > 0 || overrideTicks > 0) {
            SilentAim.clear(); return;
        }

        // ── compute step ──
        float cy = mc.field_1724.method_36454(), cp = mc.field_1724.method_36455();
        float[] step = stepTowards(mc, cy, cp);
        if (step == null) { SilentAim.clear(); return; }

        String mode = getStringSetting("mode");
        boolean vl = "On".equals(getStringSetting("vertLock"));

        switch (mode) {
            case "Silent" -> {
                SilentAim.set(step[0], vl ? cp : step[1]);
                if ("On".equals(getStringSetting("autoFire"))) silentFire(mc);
            }
            case "LockView" -> {
                mc.field_1724.method_36456(step[0]);
                mc.field_1724.method_36457(vl ? cp : step[1]);
                mc.field_1724.field_6241  = step[0];
                mc.field_1724.field_6259 = step[0];
            }
            default -> { // Rotations
                mc.field_1724.method_36456(step[0]);
                mc.field_1724.method_36457(vl ? cp : step[1]);
                mc.field_1724.field_6241  = step[0];
                mc.field_1724.field_6259 = step[0];
                mc.field_1724.field_5982     = step[0];
                mc.field_1724.field_6004     = vl ? cp : step[1];
            }
        }
    }

    public class_1297 getCurrentTarget() { return target; }
    public boolean isAimLocked()     { return target != null && reactionTicks <= 0 && overrideTicks <= 0; }

    // ── aim engine ──────────────────────────────────────────────

    private class_243 aimPoint(class_1297 e) {
        double h = e.method_5829().method_17940() * aimHeight;
        class_243 pos = e.method_5829().method_1005()
                .method_1031(0, -e.method_5829().method_17940() / 2 + h, 0);
        if (predictive && strength > 0.6)
            pos = pos.method_1019(e.method_18798().method_1021(0.9 + r.method_43058() * 0.2));
        return pos;
    }

    private void reWander() {
        double ws = 1.0 / Math.max(0.4, strength);
        aimYawOff   = (r.method_43058() - 0.5) * 4.5 * ws;
        aimPitchOff = (r.method_43058() - 0.5) * 4.0 * ws;
    }

    private float[] stepTowards(class_310 mc, float cy, float cp) {
        if (target == null || mc.field_1724 == null) return null;
        class_243 eye = mc.field_1724.method_33571();
        class_243 aim = aimPoint(target);
        class_243 delta = aim.method_1020(eye);
        double dist = delta.method_1033();
        if (dist < 0.01) return null;

        double yawTo   = Math.toDegrees(Math.atan2(-delta.field_1352, delta.field_1350));
        double pitchTo = Math.toDegrees(Math.asin(-delta.field_1351 / dist));
        double yawD    = class_3532.method_15338(yawTo - cy);
        double pitchD  = class_3532.method_15350(pitchTo - cp, -90, 90);
        double absY = Math.abs(yawD), absP = Math.abs(pitchD);

        // cubic ease-out
        double spd = baseSpeed * strength * (0.8 + r.method_43058() * 0.4);
        double easeY = ease(absY, spd, 30), easeP = ease(absP, spd * 0.65, 30);
        double stepY = class_3532.method_15350(yawD, -easeY, easeY);
        double stepP = class_3532.method_15350(pitchD, -easeP, easeP);

        // convergence damp
        if (absY < 6.0) {
            convPhase += 0.3 + r.method_43058() * 0.2;
            stepY = yawD * 0.45 + Math.sin(convPhase * 0.7) * 0.6 * (6.0 - absY) / 6.0;
        }
        if (absP < 4.0) {
            stepP = pitchD * 0.40 + Math.cos(convPhase * 0.9) * 0.45 * (4.0 - absP) / 4.0;
        }

        // hard cap
        stepY = class_3532.method_15350(stepY, -12, 12);
        stepP = class_3532.method_15350(stepP, -8, 8);

        // GCD snap
        double sens = mc.field_1690.method_42495().method_41753();
        double f = sens * 0.6 + 0.2;
        double gcd = (f * f * f) * 8.0 * 0.15;
        if (gcd > 1e-6) { stepY = Math.round(stepY / gcd) * gcd; stepP = Math.round(stepP / gcd) * gcd; }

        // tremor
        wanderPhase += 0.45 + r.method_43058() * 0.25;
        double trem = Math.sin(wanderPhase) * 0.025 * (1.0 / Math.max(0.4, strength));

        return new float[]{
            (float) class_3532.method_15338(cy + stepY + trem),
            class_3532.method_15363(cp + (float) stepP, -90, 90)
        };
    }

    private static double ease(double error, double speed, double cap) {
        if (error < 0.5) return error * 0.35;
        double t = Math.min(1.0, error / cap);
        return Math.min(speed * (0.15 + 0.85 * Math.pow(t, 0.65)), error);
    }

    // ── silent attack ───────────────────────────────────────────

    private void silentFire(class_310 mc) {
        if (mc.field_1761 == null || target == null) return;
        AutoClickerModule ac = (AutoClickerModule) QynlClient.getInstance().getModuleManager().find("AutoClicker");
        if (ac != null && ac.isEnabled()) return;
        if (mc.field_1765 instanceof class_3966) return;
        if (mc.field_1724.method_7261(0) >= 0.9F && mc.field_1724.method_56094(target, 1.0)) {
            mc.field_1761.method_2918(mc.field_1724, target);
            mc.field_1724.method_7350();
        }
    }

    // ── target selection ────────────────────────────────────────

    private class_1297 findTarget(class_310 mc) {
        double maxD  = getDoubleSetting("range");
        double maxA  = getDoubleSetting("fov");
        String tMode = getStringSetting("target");
        String prio  = getStringSetting("priority");
        class_1297 best = null;
        double bestScore = Double.MAX_VALUE;
        class_243 eye  = mc.field_1724.method_33571();
        class_243 look = mc.field_1724.method_5720();

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (e == mc.field_1724) continue;
            if (!valid(e, tMode)) continue;
            if (e instanceof class_1309 le && (!le.method_5805() || le.method_5756(mc.field_1724))) continue;
            if (e instanceof class_1657 p && Friends.isFriend(p.method_5477().getString())) continue;

            class_243 d = e.method_5829().method_1005().method_1020(eye);
            double dist = d.method_1033();
            if (dist > maxD || dist < 0.01) continue;
            double angle = Math.toDegrees(Math.acos(class_3532.method_15350(look.method_1026(d.method_1029()), -1, 1)));
            if (angle > maxA) continue;

            double sc = switch (prio) {
                case "Distance" -> dist;
                case "Health"   -> dist * 3 + (e instanceof class_1309 le2
                        ? le2.method_6032() / le2.method_6063() * 15 : 5);
                case "Angle"    -> angle * 1.5 + dist * 0.3;
                default         -> angle * 2.0 + dist * 0.5;
            };
            if (e instanceof class_1657) sc -= 2.0;
            if (sc < bestScore) { bestScore = sc; best = e; }
        }
        return best;
    }	private static boolean valid(class_1297 e, String mode) {
		return switch (mode) {
			// Hostile = the Enemy marker (zombies, skeletons, spiders, ...) —
			// never passive mobs like cows/pigs.
			case "Hostile" -> e instanceof class_1569;
			case "Players" -> e instanceof class_1657;
			default        -> e instanceof class_1569 || e instanceof class_1308 || e instanceof class_1657;
		};
	}
}