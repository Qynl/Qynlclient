package com.qynl.client.hud;

import com.qynl.client.QynlClient;
import com.qynl.client.module.Module;
import com.qynl.client.module.ModuleManager;
import com.qynl.client.module.Setting;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

/**
 * ModuleDetailScreen — the bigger per-module panel.
 *
 * <p>Opened by right-clicking a module row in the ClickGUI. Shows the
 * module name, its description, the on/off state, the keybind (with
 * set/clear), and every setting of that module. Click a setting to
 * cycle its value; click "Set key" then press a key to rebind.</p>
 */
public class ModuleDetailScreen extends class_437 {
	private static final int PANEL_W = 320;
	private static final int ROW_H = 20;
	private static final int GAP = 4;
	private static final int PANEL_BG = 0xC0121212;

	private final Module module;
	private boolean waitingForKey = false;

	public ModuleDetailScreen(Module module) {
		super(class_2561.method_43470("Module — " + module.getName()));
		this.module = module;
	}

	@Override
	protected void method_25426() {
		int centerX = this.field_22789 / 2;
		int y = 48;
		int panelLeft = centerX - PANEL_W / 2;

		// Toggle button
		this.method_37063(class_4185.method_46430(componentForState(), b -> {
					module.toggle();
					QynlClient.getInstance().getModuleManager().saveToConfig();
					refresh();
				})
				.method_46434(panelLeft, y, PANEL_W, ROW_H + 6).method_46431());
		y += ROW_H + 6 + GAP;

		// Keybind row
		this.method_37063(class_4185.method_46430(
						waitingForKey ? class_2561.method_43470("Press a key… (Esc = none)")
								: class_2561.method_43470("Keybind: " + bindLabel()),
						b -> waitingForKey = true)
				.method_46434(panelLeft, y, PANEL_W / 2 - 4, ROW_H).method_46431());
		this.method_37063(class_4185.method_46430(class_2561.method_43470("Clear"),
						b -> {
							module.setKeyCode(-1);
							waitingForKey = false;
							QynlClient.getInstance().getModuleManager().saveToConfig();
							refresh();
						})
				.method_46434(panelLeft + PANEL_W / 2 + 4, y, PANEL_W / 2 - 4, ROW_H).method_46431());
		y += ROW_H + GAP + 6;

		// Settings rows
		for (Setting<?> setting : module.getSettings()) {
			final Setting<?> s = setting;
			this.method_37063(class_4185.method_46430(
							class_2561.method_43470(s.getLabel() + ": " + s.displayString()),
							b -> {
								s.cycle();
								QynlClient.getInstance().getModuleManager().saveToConfig();
								refresh();
							})
					.method_46434(panelLeft, y, PANEL_W, ROW_H).method_46431());
			y += ROW_H + GAP;
		}
		if (!module.hasSettings()) {
			this.method_37063(class_4185.method_46430(class_2561.method_43470("No settings for this module"),
							b -> {})
					.method_46434(panelLeft, y, PANEL_W, ROW_H).method_46431());
			y += ROW_H + GAP;
		}

		y += 6;
		this.method_37063(class_4185.method_46430(class_2561.method_43470("Back"), b -> goBack())
				.method_46434(centerX - 60, y, 120, ROW_H).method_46431());
	}

	/** Returns to the ClickGUI module list instead of closing the game screen. */
	private void goBack() {
		waitingForKey = false;
		if (this.field_22787 != null) {
			this.field_22787.method_1507(new ClickGuiScreen());
		} else {
			super.method_25419();
		}
	}

	private class_2561 componentForState() {
		String state = module.isEnabled() ? "ON" : "OFF";
		return class_2561.method_43470("[" + (module.isEnabled() ? "ON" : "OFF") + "]  "
				+ module.getName());
	}

	private String bindLabel() {
		String label = module.getKeyLabel();
		return (label == null || label.isEmpty() || "None".equals(label)) ? "None" : label;
	}

	private void refresh() {
		this.method_37067();
		this.method_25426();
	}

	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers) {
		if (waitingForKey) {
			if (keyCode == GLFW.GLFW_KEY_ESCAPE
					|| keyCode == GLFW.GLFW_KEY_BACKSPACE
					|| keyCode == GLFW.GLFW_KEY_DELETE) {
				module.setKeyCode(-1);
			} else if (keyCode > 0 && !isGameCriticalKey(keyCode)) {
				module.setKeyCode(keyCode);
			}
			waitingForKey = false;
			QynlClient.getInstance().getModuleManager().saveToConfig();
			refresh();
			return true;
		}
		return super.method_25404(keyCode, scanCode, modifiers);
	}

	/** Keep a handful of keys the game needs reserved; everything else is free. */
	private boolean isGameCriticalKey(int keyCode) {
		return keyCode == GLFW.GLFW_KEY_ENTER
				|| keyCode == GLFW.GLFW_KEY_KP_ENTER
				|| keyCode == GLFW.GLFW_KEY_SLASH
				|| keyCode == GLFW.GLFW_KEY_TAB
				|| keyCode == GLFW.GLFW_KEY_F1
				|| keyCode == GLFW.GLFW_KEY_F2;
	}

	@Override
	public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		this.method_25420(guiGraphics, mouseX, mouseY, partialTick);

		int centerX = this.field_22789 / 2;
		int panelLeft = centerX - PANEL_W / 2;

		// Header
		guiGraphics.method_27534(this.field_22793,
				class_2561.method_43470(module.getName()).method_27692(class_124.field_1067),
				centerX, 14, module.isEnabled() ? HudRenderer.ACCENT : 0xFFFFFFFF);
		guiGraphics.method_27534(this.field_22793,
				class_2561.method_43470(module.getDescription()).method_27695(class_124.field_1056, class_124.field_1080),
				centerX, 28, 0xFF9CA3AF);

		// Panel background
		guiGraphics.method_25294(panelLeft - 8, 40, centerX + PANEL_W / 2 + 8, this.field_22790 - 24, PANEL_BG);

		super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		if (button == 1) {
			// Right-click anywhere = go back to the module list
			goBack();
			return true;
		}
		return super.method_25402(mouseX, mouseY, button);
	}

	@Override
	public boolean method_25421() {
		return false;
	}
}
