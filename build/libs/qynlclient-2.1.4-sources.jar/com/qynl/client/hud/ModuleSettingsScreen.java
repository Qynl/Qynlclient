package com.qynl.client.hud;

import com.qynl.client.QynlClient;
import com.qynl.client.module.Module;
import com.qynl.client.module.ModuleManager;
import com.qynl.client.module.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;

/**
 * ModuleSettingsScreen — the in-game settings editor.
 * Every module with options (mode, percentages, clicks per second, …) is
 * listed here; click a value to change it. Changes are saved instantly.
 */
public class ModuleSettingsScreen extends class_437 {
	private static final int ROW_HEIGHT = 20;
	private static final int START_Y = 44;
	private static final int COL_WIDTH = 300;

	private final List<Module> rows = new ArrayList<>();

	public ModuleSettingsScreen() {
		super(class_2561.method_43470("QynlClient — Module Settings"));
	}

	@Override
	protected void method_25426() {
		rows.clear();
		ModuleManager modules = QynlClient.getInstance().getModuleManager();
		int centerX = this.field_22789 / 2;
		int y = START_Y;

		class_7842 hint = new class_7842(
				class_2561.method_43470("Click a value to change it — saved automatically."), this.field_22793);
		hint.method_46421(centerX - COL_WIDTH / 2);
		hint.method_46419(28);
		this.method_37063(hint);

		for (Module module : modules.getModules()) {
			if (!module.hasSettings()) {
				continue;
			}
			rows.add(module);
			class_7842 header = new class_7842(
					class_2561.method_43470(module.getName()).method_27695(class_124.field_1067, class_124.field_1060),
					this.field_22793);
			header.method_46421(centerX - COL_WIDTH / 2);
			header.method_46419(y);
			this.method_37063(header);
			y += 13;

			for (Setting<?> setting : module.getSettings()) {
				final Setting<?> s = setting;
				this.method_37063(class_4185.method_46430(
						class_2561.method_43470(s.getLabel() + ": " + s.displayString()),
						b -> {
							s.cycle();
							modules.saveToConfig();
							refresh();
						}).method_46434(centerX - COL_WIDTH / 2, y, COL_WIDTH, ROW_HEIGHT - 2).method_46431());
				y += ROW_HEIGHT;
			}
			y += 5;
		}

		this.method_37063(class_4185.method_46430(class_2561.method_43470("Back"), b -> this.method_25419())
				.method_46434(centerX - 60, y + 8, 120, 20).method_46431());
	}

	private void refresh() {
		this.method_37067();
		this.method_25426();
	}

	@Override
	public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		this.method_25420(guiGraphics, mouseX, mouseY, partialTick);
		guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 12, 0xFFFFFFFF);
		super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		if (button == 1) {
			this.method_25419();
			return true;
		}
		return super.method_25402(mouseX, mouseY, button);
	}

	@Override
	public boolean method_25421() {
		return false;
	}
}
