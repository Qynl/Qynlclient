package com.qynl.client.hud;

import com.qynl.client.QynlClient;
import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.ModuleManager;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Vape-Lite style ClickGUI — dark, clean, minimal.
 *
 * <p>Category tabs across the top. Module list in the center.
 * Left-click = toggle. Right-click = settings panel.</p>
 */
public class ClickGuiScreen extends class_437 {
    private static final int ROW_H = 18;
    private static final int COL_W = 240;
    private static final int TABS_Y = 36;

    private Category selectedCategory = Category.COMBAT;
    private final List<Module> rows = new ArrayList<>();
    private final List<Integer> rowYs = new ArrayList<>();

    // ── palette ──
    private static final int BG       = 0xC8101010;
    private static final int ACCENT   = 0xFF55FF55;
    private static final int WHITE    = 0xFFD0D0D0;
    private static final int GRAY     = 0xFF7A7A7A;
    private static final int TAB_BG   = 0xC01A1A1A;
    private static final int TAB_SEL  = 0xC0222B22;
    private static final int ON_COLOR = ACCENT;
    private static final int OFF_COLOR = 0xFF555555;

    public ClickGuiScreen() { super(class_2561.method_43470("Qynl")); }

    @Override protected void method_25426() { rebuild(); }

    private void rebuild() {
        rows.clear(); rowYs.clear(); this.method_37067();

        int cx = this.field_22789 / 2, y = TABS_Y + 16;
        int lx = cx - COL_W / 2;

        // ── category tabs ──
        int tabX = cx - (Category.values().length * 58) / 2;
        for (Category cat : Category.values()) {
            boolean sel = cat == selectedCategory;
            int c = sel ? ACCENT : GRAY;
            class_4185 b = class_4185.method_46430(class_2561.method_43470(cat.getLabel()), btn -> {
                selectedCategory = cat; rebuild();
            }).method_46434(tabX, TABS_Y, 54, 14).method_46431();
            this.method_37063(b);
            tabX += 58;
        }

        // ── modules in selected category ──
        ModuleManager mm = QynlClient.getInstance().getModuleManager();
        List<Module> cats = mm.getModules().stream()
                .filter(m -> m.getCategory() == selectedCategory).toList();
        if (cats.isEmpty()) {
            this.method_37063(class_4185.method_46430(class_2561.method_43470("(none)"), b -> {})
                    .method_46434(cx - 40, y, 80, ROW_H).method_46431());
        }
        for (Module m : cats) {
            rows.add(m);
            rowYs.add(y);
            String label = m.isEnabled() ? "[ON]  " + m.getName() : "[OFF] " + m.getName();
            String key = m.getKeyLabel();
            if (key != null && !key.isEmpty() && !"None".equals(key))
                label = label + "  [" + key + "]";

            int color = m.isEnabled() ? ACCENT : GRAY;
            final String fl = label;
            class_4185 b = class_4185.method_46430(class_2561.method_43470(fl), btn -> { /* handled in mouseClicked */ })
                    .method_46434(lx, y, COL_W, ROW_H - 2).method_46431();
            this.method_37063(b);
            y += ROW_H;
        }

        // ── bottom buttons ──
        y += 4;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Keybinds\u2026"),
                b -> { if (this.field_22787 != null) this.field_22787.method_1507(new KeybindScreen()); })
                .method_46434(cx - 122, y, 76, 18).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Settings\u2026"),
                b -> { if (this.field_22787 != null) this.field_22787.method_1507(new ModuleSettingsScreen()); })
                .method_46434(cx - 38, y, 76, 18).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Close"), b -> method_25419())
                .method_46434(cx + 46, y, 76, 18).method_46431());
    }

    @Override public void method_25394(class_332 g, int mx, int my, float pt) {
        // full dark background
        g.method_25294(0, 0, this.field_22789, this.field_22790, BG);
        // title
        String title = "Qynl  v" + QynlClient.VERSION;
        g.method_25300(this.field_22793, title, this.field_22789 / 2, 8, ACCENT);
        g.method_25300(this.field_22793,
                "\u00a77L-click toggle  \u00b7  R-click settings  \u00b7  R-click outside close",
                this.field_22789 / 2, 22, 0xFF555555);

        // draw category tab backgrounds
        int tabX = this.field_22789 / 2 - (Category.values().length * 58) / 2;
        for (Category cat : Category.values()) {
            g.method_25294(tabX, TABS_Y, tabX + 54, TABS_Y + 14, cat == selectedCategory ? TAB_SEL : TAB_BG);
            if (cat == selectedCategory) g.method_25294(tabX, TABS_Y + 13, tabX + 54, TABS_Y + 14, ACCENT);
            g.method_25300(this.field_22793, cat.getLabel(), tabX + 27, TABS_Y + 3,
                    cat == selectedCategory ? ACCENT : GRAY);
            tabX += 58;
        }

        super.method_25394(g, mx, my, pt);
    }

    @Override public boolean method_25402(double mx, double my, int btn) {
        int cx = this.field_22789 / 2, halfW = COL_W / 2;

        if (btn == 1) {
            // right-click module row → detail
            for (int i = 0; i < rows.size(); i++) {
                if (mx >= cx - halfW && mx <= cx + halfW && my >= rowYs.get(i) && my <= rowYs.get(i) + ROW_H - 2) {
                    if (this.field_22787 != null) this.field_22787.method_1507(new ModuleDetailScreen(rows.get(i)));
                    return true;
                }
            }
            method_25419(); return true;
        }
        if (btn == 0) {
            for (int i = 0; i < rows.size(); i++) {
                if (mx >= cx - halfW && mx <= cx + halfW && my >= rowYs.get(i) && my <= rowYs.get(i) + ROW_H - 2) {
                    rows.get(i).toggle();
                    QynlClient.getInstance().getModuleManager().saveToConfig();
                    rebuild(); return true;
                }
            }
        }
        return super.method_25402(mx, my, btn);
    }	@Override public void method_25419() {
		super.method_25419();
	}

    @Override public boolean method_25421() { return false; }
}