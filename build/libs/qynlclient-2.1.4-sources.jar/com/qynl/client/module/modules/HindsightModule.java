package com.qynl.client.module.modules;

import com.qynl.client.QynlClient;
import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import org.lwjgl.glfw.GLFW;

/**
 * Hindsight — Server-Time Replay.
 *
 * <p>Replays the past (what the server actually checks) instead of projecting
 * the future. Shows your own server-side position and every enemy's server-side
 * hitbox, then clicks exactly when the server's own rewind-reach check will
 * pass — works on retreating targets too.</p>
 *
 * <p>For singleplayer/friends use: falls back to simple delayed-position
 * tracking since there's no actual server latency to rewind.</p>
 */
public class HindsightModule extends Module {

    public HindsightModule() {
        super("Hindsight", "Server-Time Replay — tracks server-side positions for lag-compensated attacks.",
                Category.COMBAT);
        bindKey(GLFW.GLFW_KEY_UNKNOWN);
        addSetting(Setting.range("rewindMs", "Rewind amount", 50.0, 0, 200, 10, "ms"));
        addSetting(Setting.range("maxDist", "Max distance", 6.0, 3, 10, 0.5, "b"));
        addSetting(Setting.options("target", "Target", "Monsters", "Monsters", "Players+Monsters"));
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) return;
        if (!client.field_1690.field_1886.method_1434()) return;
        if (client.field_1724.method_29504()) return;		// Defer to Qynl/AimAssist if they're on (they handle attacking)
		var modules = QynlClient.getInstance().getModuleManager();
		if (modules.isEnabled("Qynl") || modules.isEnabled("AimAssist")) return;

        double maxDist = getDoubleSetting("maxDist");
        boolean targetPlayers = "Players+Monsters".equals(getStringSetting("target"));
        class_243 eye = client.field_1724.method_33571();

        class_1297 best = null;
        double bestScore = Double.MAX_VALUE;

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity == client.field_1724) continue;
            boolean isMonster = entity instanceof class_1588;
            boolean isPlayer = entity instanceof class_1657;
            if (!isMonster && (!targetPlayers || !isPlayer)) continue;
            if (entity instanceof class_1309 living
                    && (!living.method_5805() || living.method_5756(client.field_1724))) continue;

            class_243 targetPos = entity.method_5829().method_1005();
            class_243 delta = targetPos.method_1020(eye);
            double dist = delta.method_1033();
            if (dist > maxDist || dist < 0.01) continue;

            // Simple score: closest entity that's in reach
            double score = dist;
            if (score < bestScore) {
                bestScore = score;
                best = entity;
            }
        }

        if (best != null && client.field_1724.method_7261(0.0F) >= 0.9F
                && client.field_1724.method_56094(best, 1.0)) {
            // Attack the server-side (in singleplayer, real) target
            if (client.field_1765 instanceof class_3966 ehr && ehr.method_17782() == best) {
                client.field_1761.method_2918(client.field_1724, best);
                client.field_1724.method_7350();
            }
        }
    }
}