package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import net.minecraft.class_1309;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_5819;
import org.lwjgl.glfw.GLFW;

/**
 * Criticals — The Airborne Engine.
 *
 * <p>Manages jump timing so you're airborne when attacks land, producing
 * natural critical hits. Let AutoClicker handle the actual attacking.</p>
 *
 * <p>Modes:</p>
 * <ul>
 *   <li><b>Jump</b> — auto-jump before attacks to create airborne state.</li>
 *   <li><b>Always</b> — jump whenever attacking a living target.</li>
 *   <li><b>Knockback</b> — only jump when you've been knocked back (not self-jump).</li>
 * </ul>
 */
public class CriticalsModule extends Module {
    private static final class_5819 RANDOM = class_5819.method_43047();

    private boolean forcingJump = false;
    private int jumpTicks = 0;
    private int cooldownTicks = 0;

    public CriticalsModule() {
        super("Criticals", "Airborne Engine — auto-jumps before attacks for natural crits. Works with AutoClicker.",
                Category.COMBAT);
        bindKey(GLFW.GLFW_KEY_UNKNOWN);
        addSetting(Setting.options("mode", "Mode", "Jump", "Jump", "Always", "Knockback"));
        addSetting(Setting.range("chance", "Chance", 85.0, 50, 100, 5, "%"));
        addSetting(Setting.range("cooldownMs", "Cooldown", 350.0, 100, 600, 50, "ms"));
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            reset(client);
            return;
        }
        var player = client.field_1724;
        if (player.method_29504() || player.method_7325()) {
            reset(client);
            return;
        }

        if (cooldownTicks > 0) cooldownTicks--;

        // Must be attacking and aiming at a living target
        if (!client.field_1690.field_1886.method_1434()) {
            if (forcingJump) reset(client);
            return;
        }
        if (client.field_1765 == null || client.field_1765.method_17783() != class_239.class_240.field_1331) {
            return;
        }
        if (!(client.field_1765 instanceof class_3966 ehr)) return;
        if (!(ehr.method_17782() instanceof class_1309 target) || !target.method_5805()) return;

        boolean onGround = player.method_24828();
        String mode = getStringSetting("mode");
        double chance = getDoubleSetting("chance") / 100.0;		boolean shouldJump = false;

		if ("Knockback".equals(mode)) {
			// Only jump while being combo'd (hurt window active) — the knockback
			// arc plus this jump chains crits while you're losing the trade.
			shouldJump = onGround && player.field_6235 > 0 && cooldownTicks <= 0;
		} else if ("Always".equals(mode)) {
			// Jump any time we're attacking a target on solid ground.
			shouldJump = onGround && cooldownTicks <= 0;
		} else { // Jump mode
			shouldJump = onGround && cooldownTicks <= 0 && player.method_7261(0.0F) >= 0.9F;
		}

        if (shouldJump && !forcingJump) {
            if ("Always".equals(mode) || RANDOM.method_43058() < chance) {
                client.field_1690.field_1903.method_23481(true);
                forcingJump = true;
                jumpTicks = 0;
            }
        }

        if (forcingJump) {
            jumpTicks++;
            if (!player.method_24828() && jumpTicks >= 2) {
                // We're airborne — release jump so we fall (and can then crit)
                if (client.field_1690.field_1903.method_1434()) {
                    client.field_1690.field_1903.method_23481(false);
                }
            }
            if (jumpTicks >= 10) {
                // Jump complete
                if (client.field_1690.field_1903.method_1434()) {
                    client.field_1690.field_1903.method_23481(false);
                }
                forcingJump = false;
                jumpTicks = 0;
                cooldownTicks = (int) Math.round(getDoubleSetting("cooldownMs") / 50.0);
            }
        }
    }

    private void reset(class_310 client) {
        if (forcingJump && client.field_1690 != null) {
            client.field_1690.field_1903.method_23481(false);
        }
        forcingJump = false;
        jumpTicks = 0;
        cooldownTicks = 0;
    }

    @Override
    public void onDisable() {
        reset(class_310.method_1551());
    }
}