package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_761;

/**
 * StorageESP — outlines all storage blocks through walls.
 */
public class StorageESPModule extends Module {
    private static StorageESPModule instance;

    private final Map<class_2338, Long> cache = new ConcurrentHashMap<>();
    private int scanTimer = 0;
    private class_2338 lastPos = class_2338.field_10980;
    private static final int RADIUS = 32;

    public StorageESPModule() {
        super("StorageESP", "Outlines all storage blocks through walls.",
                Category.RENDER);
        instance = this;
        bindKey(GLFW.GLFW_KEY_UNKNOWN);
        addSetting(Setting.range("opacity", "Opacity", 40.0, 10, 100, 5, "%"));
    }

    public static StorageESPModule getInstance() { return instance; }

    public void render(class_4587 poseStack, class_4597 bufferSource, class_243 camPos) {
        if (!isEnabled() || cache.isEmpty()) return;

        int alpha = (int) (getDoubleSetting("opacity") / 100.0 * 255);
        class_4588 consumer = bufferSource.getBuffer(class_1921.method_23594());
        Matrix4f matrix = poseStack.method_23760().method_23761();

        long now = System.currentTimeMillis();
        cache.entrySet().removeIf(e -> now - e.getValue() > 10000);

        for (class_2338 pos : cache.keySet()) {
            class_243 renderPos = class_243.method_24954(pos).method_1020(camPos);
            class_238 box = new class_238(renderPos.field_1352, renderPos.field_1351, renderPos.field_1350,
                    renderPos.field_1352 + 1, renderPos.field_1351 + 1, renderPos.field_1350 + 1);
            class_761.method_22982(poseStack, consumer, box, 0.0f, 0.667f, 1.0f, alpha / 255f);
        }
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        scanTimer++;
        class_2338 currentPos = client.field_1724.method_24515();
        if (scanTimer < 20 && currentPos.method_10262(lastPos) < 64) return;
        scanTimer = 0;
        lastPos = currentPos;

        class_1937 level = client.field_1687;
        cache.entrySet().removeIf(e -> e.getKey().method_10262(currentPos) > RADIUS * RADIUS);

        for (int x = -RADIUS; x <= RADIUS; x++) {
            for (int y = -RADIUS; y <= RADIUS; y++) {
                for (int z = -RADIUS; z <= RADIUS; z++) {
                    class_2338 pos = currentPos.method_10069(x, y, z);
                    if (cache.containsKey(pos) || !level.method_8477(pos)) continue;
                    class_2680 state = level.method_8320(pos);
                    if (isStorage(state)) {
                        cache.put(pos.method_10062(), System.currentTimeMillis());
                    }
                }
            }
        }
    }

    private boolean isStorage(class_2680 state) {
        String name = state.method_26204().method_9539();
        return name.contains("chest") || name.contains("barrel") || name.contains("shulker")
                || name.contains("furnace") || name.contains("hopper") || name.contains("dispenser")
                || name.contains("dropper") || name.contains("ender_chest");
    }

    @Override
    public void onDisable() { cache.clear(); }
}