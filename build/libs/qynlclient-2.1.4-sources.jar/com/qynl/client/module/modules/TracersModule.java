package com.qynl.client.module.modules;

import com.qynl.client.Friends;
import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

/**
 * Tracers — draws a colored line to every entity in range.
 * Players red, mobs orange, friends green.
 */
public class TracersModule extends Module {
    private static TracersModule instance;

    public TracersModule() {
        super("Tracers", "Draws a line to every entity in range — players red, mobs orange, friends green.",
                Category.RENDER);
        instance = this;
        bindKey(GLFW.GLFW_KEY_UNKNOWN);
        addSetting(Setting.range("maxDist", "Max distance", 64.0, 16, 128, 8, "b"));
    }

    public static TracersModule getInstance() { return instance; }

    public void render(class_4587 poseStack, class_4597 bufferSource, class_243 camPos) {
        if (!isEnabled()) return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        double maxDist = getDoubleSetting("maxDist");
        class_243 playerEye = client.field_1724.method_33571();

        class_4588 consumer = bufferSource.getBuffer(class_1921.method_23594());
        Matrix4f matrix = poseStack.method_23760().method_23761();

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity == client.field_1724) continue;
            if (!(entity instanceof class_1657 || entity instanceof class_1588)) continue;
            if (entity instanceof class_1309 living && !living.method_5805()) continue;

            class_243 entityPos = entity.method_5829().method_1005();
            double dist = playerEye.method_1022(entityPos);
            if (dist > maxDist) continue;

            class_243 renderPos = entityPos.method_1020(camPos);
            int color;
            if (entity instanceof class_1657 player) {
                color = Friends.isFriend(player.method_5477().getString()) ? 0xFF55FF55 : 0xFFFF5555;
            } else {
                color = 0xFFFF8800;
            }

            float r = ((color >> 16) & 0xFF) / 255f;
            float g = ((color >> 8) & 0xFF) / 255f;
            float b = (color & 0xFF) / 255f;

            consumer.method_22918(matrix, 0, 0, 0).method_22915(r, g, b, 1.0f);
            consumer.method_22918(matrix, (float) renderPos.field_1352, (float) renderPos.field_1351, (float) renderPos.field_1350)
                    .method_22915(r, g, b, 1.0f);
        }
    }
}