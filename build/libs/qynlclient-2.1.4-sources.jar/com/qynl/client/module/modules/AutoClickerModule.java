package com.qynl.client.module.modules;

import com.qynl.client.QynlClient;
import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5819;
import org.lwjgl.glfw.GLFW;

/**
 * AutoClicker — clicks for you with human-like timing variance.
 *
 * <p><b>Block Hit</b> (Vape-style): when enabled and holding a shield, the
 * clicker re-blocks right after every swing using post-attack blocking — the
 * block is released a tick before the swing so the attack registers
 * unblocked, then pressed again immediately after. Hold duration is
 * randomized for a human feel.</p>
 */
public class AutoClickerModule extends Module {
    private static AutoClickerModule instance;
    private final class_5819 random = class_5819.method_43047();
    private int clickTicks = 0;
    private int nextInterval = 4;
    private int burstClicks = 0;
    private int burstPause = 0;
    private double currentCps = 7.0;
    private int cpsWalkTimer = 0;

    /** Human start reaction: random beat before clicking on first key press. */
    private boolean wasHeld = false;
    private int startDelayTicks = 0;

    /** Block Hit state. */
    private int blockTicksRemaining = 0;

    public AutoClickerModule() {
        super("AutoClicker",
                "Clicks for you with human-like timing variance and optional Block Hit.",
                Category.COMBAT);
        instance = this;
        bindKey(GLFW.GLFW_KEY_G);
        addSetting(Setting.range("cps",        "Target CPS", 9.0, 5, 16, 1));
        addSetting(Setting.range("jitter",     "Jitter",      8.0, 0, 20, 1, "%"));
        addSetting(Setting.options("pattern",  "Pattern",    "Steady", "Steady", "Burst"));
        addSetting(Setting.options("blockhit", "Block Hit",  "Off",    "Off",    "On"));
        addSetting(Setting.range("blockChance","Block chance", 100.0, 0, 100, 5, "%"));
        addSetting(Setting.range("blockTicks", "Block time",    4.0,  1,   8,  1, "t"));
        addSetting(Setting.range("blockRange", "Block range",   3.5,  2.0, 5.0, 0.5, "b"));
    }

    public static boolean isActive() { return instance != null && instance.isEnabled(); }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
            resetState(client);
            return;
        }
        if (client.field_1755 != null || !client.field_1690.field_1886.method_1434()) {
            resetState(client);
            return;
        }
        // Never click while the player is eating, drinking or using an item —
        // attacking would cancel the use and the pattern is suspicious.
        if (client.field_1724.method_6115()) {
            if (blockTicksRemaining > 0) {
                blockTicksRemaining = 0;
                releaseUse(client);
            }
            return;
        }

        // Humans don't start clicking the instant they press the button —
        // wait a short random beat on the first press (100–300 ms).
        if (!wasHeld) {
            wasHeld = true;
            startDelayTicks = 2 + random.method_43048(5);
            clickTicks = 0;
            return;
        }
        if (startDelayTicks > 0) {
            startDelayTicks--;
            return;
        }

        // The standalone BlockHit module takes over blocking when active.
        boolean blockhit = "On".equals(getStringSetting("blockhit")) && !BlockHitModule.isActive();
        boolean holdingShield = holdingShield(client.field_1724.method_6047())
                || holdingShield(client.field_1724.method_6079());

        // Maintain an active block hold from the previous swing.
        if (blockhit && holdingShield && blockTicksRemaining > 0) {
            blockTicksRemaining--;
            if (blockTicksRemaining > 0) {
                pressUse(client);
            } else {
                releaseUse(client);
            }
        } else if (blockTicksRemaining > 0) {
            blockTicksRemaining = 0;
            releaseUse(client);
        }

        // Slow random walk of the target CPS.
        cpsWalkTimer++;
        if (cpsWalkTimer >= 40) {
            cpsWalkTimer = 0;
            double targetCps = getDoubleSetting("cps");
            currentCps = Math.max(2, Math.min(16, currentCps + (random.method_43058() - 0.5) * 1.0));
            currentCps = currentCps + (targetCps - currentCps) * 0.2;
        }

        // Burst mode: click 2-4 times fast, then pause briefly.
        if ("Burst".equals(getStringSetting("pattern")) && burstPause > 0) {
            burstPause--;
            clickTicks = 0;
            return;
        }

        clickTicks++;
        if (clickTicks < nextInterval) return;
        clickTicks = 0;

        double baseCps = getDoubleSetting("cps");
        double jitter = getDoubleSetting("jitter") / 100.0;
        currentCps += (random.method_43058() - 0.5) * jitter * 4.0;
        currentCps = Math.max(baseCps * (1.0 - jitter), Math.min(baseCps * (1.0 + jitter), currentCps));
        double effectiveCps = Math.max(1, currentCps);
        nextInterval = Math.max(1, (int) Math.round(20.0 / effectiveCps) + random.method_43048(5) - 2);

        // Occasional missed click — human click streams have gaps.
        if (random.method_43048(100) < 3) {
            nextInterval *= 2;
            return;
        }

        // Respect the attack cooldown (1.9+ combat).
        if (client.field_1724.method_7261(0.0F) < 0.6F) return;

        // Post-attack blocking: the swing always lands unblocked, then the
        // block comes up right after it. Never blocks at air.
        if (blockhit && holdingShield) {
            releaseUse(client);
        }

        click(client);

        // Block holds only happen on the ground, with an enemy in melee range.
        if (blockhit && holdingShield && client.field_1724.method_24828()
                && enemyInRange(client)
                && (random.method_43058() * 100.0) < getDoubleSetting("blockChance")) {
            int hold = (int) getDoubleSetting("blockTicks");
            hold += random.method_43048(3) - 1; // humanize
            if (hold < 1) hold = 1;
            blockTicksRemaining = hold;
            // Briefly drop sprint so the server sees correct block physics.
            if (client.field_1724.method_5624()) {
                client.field_1724.method_5728(false);
            }
            pressUse(client);
        }

        // Burst tracking.
        if ("Burst".equals(getStringSetting("pattern"))) {
            burstClicks++;
            if (burstClicks >= 2 + random.method_43048(3)) {
                burstClicks = 0;
                burstPause = 3 + random.method_43048(4);
            }
        }
    }

    /** Performs one click: entity attack if aiming at one, else block-break. */
    private void click(class_310 client) {
        if (client.field_1765 == null) return;
        if (client.field_1765.method_17783() == class_239.class_240.field_1331) {
            class_1297 target = ((class_3966) client.field_1765).method_17782();
            client.field_1724.method_6104(net.minecraft.class_1268.field_5808);
            client.field_1761.method_2918(client.field_1724, target);
        } else if (client.field_1765.method_17783() == class_239.class_240.field_1332) {
            class_3965 hit = (class_3965) client.field_1765;
            class_2338 pos = hit.method_17777();
            class_2350 side = hit.method_17780();
            if (client.field_1761.method_2923()) {
                client.field_1761.method_2902(pos, side);
            } else {
                client.field_1761.method_2910(pos, side);
            }
        }
    }

    /** True while a non-friend enemy stands within the block range. */
    private boolean enemyInRange(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return false;
        double range = getDoubleSetting("blockRange");
        double rangeSq = range * range;
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1309)) continue;
            class_1309 living = (class_1309) entity;
            if (living == client.field_1724 || !living.method_5805()) continue;
            if (!(living instanceof class_1588) && !(living instanceof class_1657)) continue;
            if (FriendsModule.isFriend(FriendsModule.entityName(living))) continue;
            double dx = living.method_23317() - client.field_1724.method_23317();
            double dy = living.method_23318() - client.field_1724.method_23318();
            double dz = living.method_23321() - client.field_1724.method_23321();
            if (dx * dx + dy * dy + dz * dz <= rangeSq) return true;
        }
        return false;
    }

    private static boolean holdingShield(class_1799 stack) {
        return stack != null && stack.method_7909() == class_1802.field_8255;
    }

    private void pressUse(class_310 client) {
        if (!client.field_1690.field_1904.method_1434()) {
            client.field_1690.field_1904.method_23481(true);
        }
    }

    private void releaseUse(class_310 client) {
        if (client.field_1690.field_1904.method_1434()) {
            client.field_1690.field_1904.method_23481(false);
        }
    }

    private void resetState(class_310 client) {
        clickTicks = 0;
        burstClicks = 0;
        burstPause = 0;
        wasHeld = false;
        startDelayTicks = 0;
        if (blockTicksRemaining > 0) {
            blockTicksRemaining = 0;
            if (client != null && client.field_1690 != null) {
                releaseUse(client);
            }
        }
    }

    @Override
    public void onDisable() {
        resetState(class_310.method_1551());
    }
}
