package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_243;
import net.minecraft.class_2767;
import net.minecraft.class_310;
import net.minecraft.class_3417;

/**
 * Echo — Soundscape radar.
 *
 * <p>Listens to the server's own sound packets (read-only) and records
 * fading 3D markers: red for player activity, magenta for ender-pearl
 * landings, gold for mobs, green for utility, grey for ambient.
 * Zero packets sent — unflagable by construction.</p>
 */
public class EchoModule extends Module {
    private static EchoModule instance;

    private final List<EchoMarker> markers = new ArrayList<>();
    private int cleanupTimer = 0;

    public EchoModule() {
        super("Echo", "Soundscape radar — listens to sound packets and shows fading 3D markers.",
                Category.RENDER);
        instance = this;
        bindKey(GLFW.GLFW_KEY_UNKNOWN);
        addSetting(Setting.range("fadeMs", "Fade time", 3000.0, 1000, 8000, 500, "ms"));
        addSetting(Setting.range("maxMarkers", "Max markers", 32.0, 8, 64, 4));
    }

    public static EchoModule getInstance() { return instance; }

    /** Called from packet mixin when a sound packet arrives. */
    public static void onSoundPacket(class_2767 packet) {
        if (instance == null || !instance.isEnabled()) return;
        if (packet.method_11894() == null) return;

        class_243 pos = new class_243(packet.method_11890(), packet.method_11889(), packet.method_11893());

        int color;
        var sound = packet.method_11894().comp_349();

        if (sound == class_3417.field_14706 || sound == class_3417.field_14999
                || sound == class_3417.field_15115 || sound == class_3417.field_14904
                || sound == class_3417.field_14600 || sound == class_3417.field_15187) {
            color = 0xFFFF5555; // Player activity — red
        } else if (sound == class_3417.field_14757 || sound == class_3417.field_14890
                || sound == class_3417.field_14879) {
            color = 0xFFFF00FF; // Pearl/teleport — magenta
        } else if (sound == class_3417.field_15174 || sound == class_3417.field_15200
                || sound == class_3417.field_15057 || sound == class_3417.field_15170
                || sound == class_3417.field_14588 || sound == class_3417.field_15231
                || sound == class_3417.field_14970) {
            color = 0xFFFFAA00; // Mobs — gold
        } else if (sound == class_3417.field_14982 || sound == class_3417.field_14823
                || sound == class_3417.field_14664 || sound == class_3417.field_14541
                || sound == class_3417.field_14567 || sound == class_3417.field_14819
                || sound == class_3417.field_14766 || sound == class_3417.field_14861
                || sound == class_3417.field_14932 || sound == class_3417.field_15080
                || sound == class_3417.field_15082 || sound == class_3417.field_15131
                || sound == class_3417.field_14962 || sound == class_3417.field_14791
                || sound == class_3417.field_14699) {
            color = 0xFF55FF55; // Utility — green
        } else {
            color = 0xFF808080; // Ambient — grey, but only if interesting
            // Filter out common ambient sounds to avoid spam
            if (sound == class_3417.field_14564.comp_349()) return;
            if (packet.method_11891() < 0.5f) return;
        }

        instance.markers.add(new EchoMarker(pos, color, System.currentTimeMillis()));
    }

    public List<EchoMarker> getMarkers() {
        return List.copyOf(markers);
    }

    @Override
    public void onTick(class_310 client) {
        if (!isEnabled()) return;
        cleanupTimer++;
        if (cleanupTimer < 10) return;
        cleanupTimer = 0;

        long now = System.currentTimeMillis();
        long fade = (long) getDoubleSetting("fadeMs");
        int maxMarkers = (int) getDoubleSetting("maxMarkers");

        markers.removeIf(m -> now - m.timestamp() > fade);
        while (markers.size() > maxMarkers) {
            markers.remove(0);
        }
    }

    @Override
    public void onDisable() {
        markers.clear();
    }

    public record EchoMarker(class_243 pos, int color, long timestamp) {}
}