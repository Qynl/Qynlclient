package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

public class ZoomModule extends Module {
	private static final double ZOOM_LEVEL = 2.5;

	private double baseFov = -1.0;
	private double baseSensitivity = -1.0;

	public ZoomModule() {
		super("Zoom", "Hold the key to zoom in for a closer look.", Category.RENDER);
		bindKey(GLFW.GLFW_KEY_Z);
	}

	@Override
	public void onEnable() {
		class_310 client = class_310.method_1551();
		if (client.field_1690 == null) {
			return;
		}
		baseFov = client.field_1690.method_41808().method_41753();
		baseSensitivity = client.field_1690.method_42495().method_41753();
		applyZoom(client, true);
	}

	@Override
	public void onTick(class_310 client) {
		if (client.field_1690 == null) {
			return;
		}
		if (getKeyMapping() != null && getKeyMapping().method_1434()) {
			if (baseFov < 0) {
				baseFov = client.field_1690.method_41808().method_41753();
				baseSensitivity = client.field_1690.method_42495().method_41753();
			}
			applyZoom(client, true);
		} else {
			applyZoom(client, false);
		}
	}

	@Override
	public void onDisable() {
		class_310 client = class_310.method_1551();
		applyZoom(client, false);
		baseFov = -1.0;
		baseSensitivity = -1.0;
	}

	private void applyZoom(class_310 client, boolean zoomed) {
		if (client.field_1690 == null) {
			return;
		}
		if (zoomed && baseFov >= 0) {
			client.field_1690.method_41808().method_41748((int) Math.round(baseFov / ZOOM_LEVEL));
			client.field_1690.method_42495().method_41748(baseSensitivity / ZOOM_LEVEL);
		} else {
			if (baseFov >= 0) {
				client.field_1690.method_41808().method_41748((int) Math.round(baseFov));
			}
			if (baseSensitivity >= 0) {
				client.field_1690.method_42495().method_41748(baseSensitivity);
			}
		}
	}
}
