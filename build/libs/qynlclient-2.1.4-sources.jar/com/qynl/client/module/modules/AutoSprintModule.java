package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import org.lwjgl.glfw.GLFW;

/**
 * AutoSprint — sprint automatically while you move forward, without holding
 * the sprint key.
 *
 * <p>Anti-cheat hardened: sprint starts with a randomized delay after you
 * start moving (humans don't sprint the instant they press W), never
 * re-engages within 5 ticks after an attack (vanilla cancels sprint on attack
 * and real players take a moment to re-engage), and occasionally misses the
 * start and retries. Uses the same vanilla sprint rules (food, not sneaking,
 * not using an item) so the pattern matches a normal player perfectly.</p>
 */
public class AutoSprintModule extends Module {
    private static final class_5819 RANDOM = class_5819.method_43047();

    private int startDelayTicks = 0;
    private int lastAttackTick = -100;
    private boolean wasSwinging = false;
    private int tickCounter = 0;

    public AutoSprintModule() {
        super("AutoSprint", "Sprint automatically while you move — no need to hold the sprint key.",
                Category.COMBAT);		bindKey(GLFW.GLFW_KEY_Y);
		addSetting(Setting.options("mode", "Mode", "Forward", "Forward", "Always"));
		// On by default, like every quality client — sprinting is expected
		// behaviour, not a feature you have to discover.
		setEnabled(true);
	}

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        var player = client.field_1724;
        tickCounter++;

        // Track our own swings: vanilla cancels sprint on attack, and
        // re-sprinting instantly after a hit is a bot signature.
        boolean swinging = player.field_6252;
        if (swinging && !wasSwinging) {
            lastAttackTick = tickCounter;
        }
        wasSwinging = swinging;

        if (player.method_5624()) {
            return;
        }

        boolean moving = "Always".equals(getStringSetting("mode"))
                ? (player.field_3913.field_3905 > 0.0F || player.field_3913.field_3907 != 0.0F)
                : player.field_3913.field_3905 > 0.0F;
        if (!moving) {
            startDelayTicks = 0;
            return;
        }

        // Randomized start delay after movement begins (3–7 ticks).
        if (startDelayTicks == 0) {
            startDelayTicks = 3 + RANDOM.method_43048(5);
            return;
        }
        if (--startDelayTicks > 0) {
            return;
        }

        // Respect the post-attack sprint re-engage window.
        if (tickCounter - lastAttackTick < 5) {
            return;
        }
        // Occasionally miss the sprint start and retry next tick.
        if (RANDOM.method_43048(100) < 10) {
            return;
        }

        boolean canSprint = player.method_7344().method_7586() > 6
                && !player.method_18276()
                && !player.method_6115()
                && !player.method_5765();
        if (canSprint) {
            player.method_5728(true);
        }
    }

    @Override
    public void onDisable() {
        startDelayTicks = 0;
    }
}
