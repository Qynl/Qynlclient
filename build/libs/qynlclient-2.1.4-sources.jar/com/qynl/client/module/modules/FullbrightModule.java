package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

public class FullbrightModule extends Module {
	private double originalGamma = -1.0;

	public FullbrightModule() {
		super("Fullbright", "Boost brightness so you can see clearly in the dark.", Category.RENDER);
		bindKey(GLFW.GLFW_KEY_K);
	}

	@Override
	public void onEnable() {
		class_310 client = class_310.method_1551();
		if (client.field_1690 != null) {
			if (originalGamma < 0) {
				originalGamma = client.field_1690.method_42473().method_41753();
			}
			client.field_1690.method_42473().method_41748(1.0);
		}
	}

	@Override
	public void onDisable() {
		class_310 client = class_310.method_1551();
		if (client.field_1690 != null && originalGamma >= 0) {
			client.field_1690.method_42473().method_41748(originalGamma);
			originalGamma = -1.0;
		}
	}

	@Override
	public void onTick(class_310 client) {
		if (client.field_1690 != null && client.field_1690.method_42473().method_41753() < 1.0) {
			client.field_1690.method_42473().method_41748(1.0);
		}
	}
}
