package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_310;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;

/**
 * Refill — refills your hotbar with food and potions from inventory.
 * Press the key or set to auto mode.
 */
public class RefillModule extends Module {
    private int cooldown = 0;

    public RefillModule() {
        super("Refill", "Refills your hotbar with food and potions from your inventory.",
                Category.UTILITY);
        bindKey(GLFW.GLFW_KEY_UNKNOWN);
        addSetting(Setting.options("mode", "Mode", "Manual", "Manual", "Auto"));
        addSetting(Setting.range("delay", "Swap delay", 5.0, 2, 15, 1, "t"));
        addSetting(Setting.range("threshold", "Refill at", 3.0, 1, 8, 1, "items"));
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null) return;
        if (client.field_1724.method_29504() || client.field_1755 != null) return;

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        String mode = getStringSetting("mode");
        int threshold = (int) getDoubleSetting("threshold");

        // Auto mode
        if ("Auto".equals(mode)) {
            refillHotbar(client, threshold);
        }
        // Manual mode: press the toggle key to refill once
        // (handled by onEnable calling refill once in manual mode)
    }	@Override
	public void onEnable() {
		class_310 client = class_310.method_1551();
		// onEnable can fire during client init (config restore) before the
		// player/world exists — never touch inventory in that window.
		if (client.field_1724 == null || client.field_1687 == null) {
			return;
		}
		if ("Manual".equals(getStringSetting("mode"))) {
			refillHotbar(client, (int) getDoubleSetting("threshold"));
		}
	}	private void refillHotbar(class_310 client, int threshold) {
		var player = client.field_1724;
		if (player == null || client.field_1761 == null) {
			return;
		}
		class_1661 inv = player.method_31548();

        // Check slots 0-8 (hotbar): if empty or stack is low, try to refill
        for (int hotbarSlot = 0; hotbarSlot < 9; hotbarSlot++) {
            class_1799 stack = inv.method_5438(hotbarSlot);
            if (stack.method_7960()) continue;

            boolean shouldRefill = (stack.method_7914() > 1 && stack.method_7947() <= threshold);
            if (!shouldRefill) continue;

            // Find a matching item in inventory (slots 9-35)
            for (int invSlot = 9; invSlot < 36; invSlot++) {
                class_1799 invStack = inv.method_5438(invSlot);
                if (invStack.method_7960()) continue;
                if (!class_1799.method_31577(stack, invStack)) continue;

                int fromSlot = invSlot;
                int toSlot = hotbarSlot < 9 ? 36 + hotbarSlot : hotbarSlot;
                int containerId = player.field_7512.field_7763;

                // Swap
                client.field_1761.method_2906(containerId, fromSlot, 0, class_1713.field_7790, player);
                client.field_1761.method_2906(containerId, toSlot, 0, class_1713.field_7790, player);
                if (!player.field_7512.method_34255().method_7960()) {
                    client.field_1761.method_2906(containerId, fromSlot, 0, class_1713.field_7790, player);
                }

                cooldown = (int) getDoubleSetting("delay");
                return; // One swap per tick to avoid spam
            }
        }

        // Also fill empty hotbar slots with food/potions
        for (int hotbarSlot = 0; hotbarSlot < 9; hotbarSlot++) {
            if (!inv.method_5438(hotbarSlot).method_7960()) continue;

            for (int invSlot = 9; invSlot < 36; invSlot++) {
                class_1799 invStack = inv.method_5438(invSlot);
                if (invStack.method_7960()) continue;
                if (isFood(invStack) || isPotion(invStack)) {
                    int fromSlot = invSlot;
                    int toSlot = 36 + hotbarSlot;
                    int containerId = player.field_7512.field_7763;

                    client.field_1761.method_2906(containerId, fromSlot, 0, class_1713.field_7790, player);
                    client.field_1761.method_2906(containerId, toSlot, 0, class_1713.field_7790, player);
                    if (!player.field_7512.method_34255().method_7960()) {
                        client.field_1761.method_2906(containerId, fromSlot, 0, class_1713.field_7790, player);
                    }

                    cooldown = (int) getDoubleSetting("delay");
                    return;
                }
            }
        }
    }

    private boolean isFood(class_1799 stack) {
        return stack.method_57824(class_9334.field_50075) != null
                && stack.method_7909() != class_1802.field_8233
                && stack.method_7909() != class_1802.field_8511
                && stack.method_7909() != class_1802.field_8680
                && stack.method_7909() != class_1802.field_8635;
    }

    private boolean isPotion(class_1799 stack) {
        class_1844 contents = stack.method_57824(class_9334.field_49651);
        return contents != null;
    }
}