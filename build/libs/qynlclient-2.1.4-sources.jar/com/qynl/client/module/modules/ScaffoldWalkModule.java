package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import org.lwjgl.glfw.GLFW;

/**
 * ScaffoldWalk — places a block under your feet automatically while you
 * walk, so crossing gaps, bridging over lava and climbing out of holes
 * needs no precise aim and no fast clicking. Just walk forward and the
 * floor builds itself.
 */
public class ScaffoldWalkModule extends Module {
	private int cooldown = 0;

	public ScaffoldWalkModule() {
		super("ScaffoldWalk", "Places blocks under you as you walk, so you never fall.",
				Category.UTILITY);
		bindKey(GLFW.GLFW_KEY_B);
		addSetting(Setting.range("cooldown", "Place delay", 3.0, 1, 10, 1, "t"));
	}

	@Override
	public void onTick(class_310 client) {
		if (cooldown > 0) {
			cooldown--;
			return;
		}
		int placeCooldown = (int) getDoubleSetting("cooldown");
		if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
			return;
		}
		var player = client.field_1724;
		if (player.method_7325() || player.method_5765() || player.method_6115()
				|| player.method_31549().field_7479) {
			return;
		}

		class_243 velocity = player.method_18798();
		int dx = (int) Math.signum(velocity.field_1352);
		int dz = (int) Math.signum(velocity.field_1350);

		class_2338 feet = player.method_23314();
		class_2338 target = feet.method_10069(dx, 0, dz);
		if (dx == 0 && dz == 0) {
			// Standing still: only fill a hole directly under the player.
			target = feet;
		}
		if (!client.field_1687.method_22347(target)) {
			return;
		}

		class_2338 support = findSupport(client, target, dx, dz);
		if (support == null) {
			return;
		}
		class_2350 dir = class_2350.method_50026(
				target.method_10263() - support.method_10263(),
				target.method_10264() - support.method_10264(),
				target.method_10260() - support.method_10260());
		if (dir == null) {
			return;
		}

		class_1661 inventory = player.method_31548();
		int slot = findBlockSlot(inventory);
		if (slot < 0) {
			return;
		}
		if (inventory.field_7545 != slot) {
			inventory.field_7545 = slot;
		}

		class_3965 hit = new class_3965(
				class_243.method_24953(support)
						.method_1031(dir.method_10148() * 0.5, dir.method_10164() * 0.5, dir.method_10165() * 0.5),
				dir, support, false);
		if (player.method_33571().method_1022(hit.method_17784()) > 5.0) {
			return;
		}
		player.method_6104(class_1268.field_5808);
		client.field_1761.method_2896(player, class_1268.field_5808, hit);
		cooldown = placeCooldown;
	}

	/** Finds a solid block to place the target block against. */
	private class_2338 findSupport(class_310 client, class_2338 target, int dx, int dz) {
		// Prefer placing straight up onto the block below.
		if (isSolid(client, target.method_10074())) {
			return target.method_10074();
		}
		// Then the block behind (where the player stands or last placed).
		class_2338 behind = target.method_10069(-dx, 0, -dz);
		if (isSolid(client, behind)) {
			return behind;
		}
		// Finally, any solid horizontal neighbour.
		for (class_2350 dir : class_2350.class_2353.field_11062) {
			class_2338 n = target.method_10093(dir);
			if (isSolid(client, n)) {
				return n;
			}
		}
		return null;
	}

	private boolean isSolid(class_310 client, class_2338 pos) {
		return !client.field_1687.method_8320(pos).method_26220(client.field_1687, pos).method_1110();
	}

	/** Finds a placeable block item in the hotbar, preferring the selected slot. */
	private int findBlockSlot(class_1661 inventory) {
		if (isPlaceable(inventory.method_5438(inventory.field_7545))) {
			return inventory.field_7545;
		}
		for (int i = 0; i < 9; i++) {
			if (i != inventory.field_7545 && isPlaceable(inventory.method_5438(i))) {
				return i;
			}
		}
		return -1;
	}

	private boolean isPlaceable(class_1799 stack) {
		if (stack.method_7960() || !(stack.method_7909() instanceof class_1747 item)) {
			return false;
		}
		return item.method_7711() != class_2246.field_10124;
	}
}
