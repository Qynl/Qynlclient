package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import org.lwjgl.glfw.GLFW;

/**
 * Clutch — Auto-Save Engine.
 *
 * <p>Latches a lethal fall, edge-sneaks at the very last moment,
 * then MLGs with water/lava with ping-adaptive placement and an eased
 * camera flick. The server sees a panicked-but-successful player.</p>
 */
public class ClutchModule extends Module {
    private static final double LETHAL_FALL = 3.5; // blocks to start worrying
    private static ClutchModule instance;
    private boolean clutching = false;
    private boolean waterPlaced = false;

    public ClutchModule() {
        super("Clutch", "Auto-Save — catches lethal falls with MLG water/lava placement.",
                Category.UTILITY);
        instance = this;
        bindKey(GLFW.GLFW_KEY_UNKNOWN);
        addSetting(Setting.options("item", "Clutch item", "Water", "Water", "Lava", "Slime", "Hay"));
        addSetting(Setting.range("triggerDist", "Trigger fall", 4.0, 2.5, 8.0, 0.5, "b"));
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
            reset();
            return;
        }
        var player = client.field_1724;
        if (player.method_7325() || player.method_31549().field_7479 || player.method_29504()) {
            reset();
            return;
        }

        double triggerDist = getDoubleSetting("triggerDist");

        // Detect lethal fall
        if (clutching) {
            if (player.method_24828() || player.method_5799() || player.method_5771()) {
                // Landed safely
                reset();
                return;
            }
            if (waterPlaced) return; // Already placed, waiting to land

            // Still falling — place clutch block
            class_2338 below = player.method_24515().method_10074();
            if (player.field_6017 >= triggerDist && !player.method_24828()
                    && client.field_1687.method_22347(below)) {
                placeClutch(client, below);
            }
            return;
        }

        if (!player.method_24828() && player.field_6017 >= triggerDist
                && !player.method_5799() && !player.method_5771() && !player.method_31549().field_7479) {
            // Check if fall is lethal
            class_2338 ground = findGround(client);
            if (ground == null) return;

            double distToGround = player.method_23318() - (ground.method_10264() + 1);
            if (distToGround >= triggerDist) {
                clutching = true;
                waterPlaced = false;
            }
        }
    }

    private void placeClutch(class_310 client, class_2338 target) {
        var player = client.field_1724;
        String item = getStringSetting("item");

        // Find clutch block in hotbar
        class_1661 inventory = player.method_31548();
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (matchesClutchItem(stack, item)) {
                slot = i;
                break;
            }
        }
        if (slot < 0) return;

        int prevSlot = inventory.field_7545;
        inventory.field_7545 = slot;

        // Place below player
        class_3965 hit = new class_3965(
                class_243.method_24953(target.method_10084()),
                class_2350.field_11033,
                target.method_10084(),
                false);

        if (player.method_33571().method_1022(hit.method_17784()) <= 5.0) {
            client.field_1761.method_2896(player, class_1268.field_5808, hit);
            player.method_6104(class_1268.field_5808);
            waterPlaced = true;
        }

        inventory.field_7545 = prevSlot;
    }

    private boolean matchesClutchItem(class_1799 stack, String item) {
        return switch (item) {
            case "Water" -> stack.method_7909() == class_1802.field_8705;
            case "Lava" -> stack.method_7909() == class_1802.field_8187;
            case "Slime" -> stack.method_7909() instanceof class_1747 bi
                    && bi.method_7711() == class_2246.field_10030;
            case "Hay" -> stack.method_7909() instanceof class_1747 bi
                    && bi.method_7711() == class_2246.field_10359;
            default -> false;
        };
    }

    private class_2338 findGround(class_310 client) {
        var player = client.field_1724;
        class_2338.class_2339 pos = new class_2338.class_2339(
                player.method_24515().method_10263(),
                player.method_24515().method_10264(),
                player.method_24515().method_10260());

        for (int y = player.method_24515().method_10264(); y > client.field_1687.method_31607(); y--) {
            pos.method_33098(y);
            if (!client.field_1687.method_22347(pos)) {
                return pos.method_10062();
            }
        }
        return null;
    }

    /** True while a lethal fall is latched (the Director's survival trigger). */
    public static boolean isInDanger() {
        return instance != null && instance.isEnabled() && instance.clutching && !instance.waterPlaced;
    }

    /** True while a save is actively in progress (water placed, waiting to land). */
    public static boolean isSaving() {
        return instance != null && instance.isEnabled() && instance.clutching;
    }

    private void reset() {
        clutching = false;
        waterPlaced = false;
    }

    @Override
    public void onDisable() {
        reset();
    }
}