package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import org.lwjgl.glfw.GLFW;

/**
 * BlockHit — Vape-Lite-grade auto-blocking.
 *
 * <p>Two modes:</p>
 * <ul>
 *   <li><b>Reactive</b> — blocks when an enemy swings at you (human reaction delay).</li>
 *   <li><b>Rhythm</b> — re-blocks after your own swings with attacks landing
 *       unblocked (post-attack blocking). Sprint-reset before every block.</li>
 * </ul>
 *
 * <p>Only works with a sword or axe in hand, never blocks at air,
 * never touches manual item use.</p>
 */
public class BlockHitModule extends Module {
    private static final class_5819 RANDOM = class_5819.method_43047();
    private static BlockHitModule instance;

    private boolean forcingBlock = false;
    private int blockTimer = 0;
    private int cooldownTicks = 0;
    private int reactionTicks = 0;
    private boolean swungThisTick = false;
    private int postAttackTicks = 0;

    public BlockHitModule() {
        super("BlockHit", "Auto-blocks when enemy attacks (Reactive) or after your swings (Rhythm).",
                Category.COMBAT);
        instance = this;
        bindKey(GLFW.GLFW_KEY_UNKNOWN);
        addSetting(Setting.options("mode", "Mode", "Reactive", "Reactive", "Rhythm"));
        addSetting(Setting.range("reactionMs", "Reaction delay", 150.0, 50, 300, 10, "ms"));
        addSetting(Setting.range("blockTicks", "Block duration", 3.0, 2, 8, 1, "t"));
        addSetting(Setting.range("chance", "Chance", 80.0, 50, 100, 5, "%"));
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            reset();
            return;
        }
        if (client.field_1724.method_29504()) {
            reset();
            return;
        }		// Must hold a sword/axe (1.21.1: blocking needs a shield — sword/axe in
		// the main hand plus a shield in either hand is the real melee kit).
		class_1799 held = client.field_1724.method_6047();
		boolean hasWeapon = (held.method_7909() instanceof class_1829 || held.method_7909() instanceof class_1743)
				|| held.method_7909() == net.minecraft.class_1802.field_8255
				|| client.field_1724.method_6079().method_7909() == net.minecraft.class_1802.field_8255;
		if (!hasWeapon) {
			reset();
			return;
		}

        if (cooldownTicks > 0) {
            cooldownTicks--;
        }

        if (reactionTicks > 0) {
            reactionTicks--;
        }

        // Detect our own swing
        boolean nowSwinging = client.field_1690.field_1886.method_1434();
        if (!swungThisTick && nowSwinging && client.field_1724.method_7261(0.0F) >= 0.9F) {
            swungThisTick = true;
            postAttackTicks = 2; // window after swing to re-block
        }
        if (!nowSwinging) {
            swungThisTick = false;
        }
        if (postAttackTicks > 0) postAttackTicks--;

        // While blocking, count down
        if (forcingBlock) {
            if (blockTimer > 0) {
                blockTimer--;
                if (!client.field_1690.field_1904.method_1434()) {
                    client.field_1690.field_1904.method_23481(true);
                }
                return;
            }
            releaseBlock(client);
            cooldownTicks = 3 + RANDOM.method_43048(5);
            return;
        }

        if (cooldownTicks > 0) return;

        // Don't interfere with player's own right-click
        if (client.field_1690.field_1904.method_1434() || client.field_1724.method_6115()) return;

        double chance = getDoubleSetting("chance") / 100.0;
        String mode = getStringSetting("mode");

        if ("Reactive".equals(mode)) {
            // Block when enemy is about to hit us
            class_1309 enemy = findAttackingEnemy(client);
            if (enemy == null) return;

            if (reactionTicks > 0) return;
            if (RANDOM.method_43058() > chance) return;

            startBlock(client);
            reactionTicks = (int) Math.round(getDoubleSetting("reactionMs") / 50.0) + RANDOM.method_43048(3);
        } else {
            // Rhythm: re-block after our own swings
            if (postAttackTicks <= 0) return;
            if (RANDOM.method_43058() > chance) return;

            // Only rhythm-block when an enemy is in range
            class_1309 enemy = findNearbyEnemy(client);
            if (enemy == null) return;

            startBlock(client);
        }
    }

    private void startBlock(class_310 client) {
        // Sprint-reset before block
        if (client.field_1724.method_5624()) {
            client.field_1724.method_5728(false);
        }
        client.field_1690.field_1904.method_23481(true);
        forcingBlock = true;
        blockTimer = (int) getDoubleSetting("blockTicks") + RANDOM.method_43048(3) - 1;
        if (blockTimer < 2) blockTimer = 2;
    }

    private void releaseBlock(class_310 client) {
        if (client.field_1690 != null) client.field_1690.field_1904.method_23481(false);
        forcingBlock = false;
        blockTimer = 0;
    }

    private void reset() {
        class_310 client = class_310.method_1551();
        releaseBlock(client);
        reactionTicks = 0;
        cooldownTicks = 0;
        postAttackTicks = 0;
        swungThisTick = false;
    }

    private class_1309 findAttackingEnemy(class_310 client) {
        var player = client.field_1724;
        var box = player.method_5829().method_1014(3.5);
        class_1309 best = null;
        double bestDist = Double.MAX_VALUE;

        for (var entity : client.field_1687.method_8333(player, box,
                e -> e instanceof class_1309 && e.method_5805()
                        && (e instanceof class_1588 || e instanceof class_1657) && e != player)) {
            if (!(entity instanceof class_1309 living)) continue;
            double dist = living.method_5739(player);
            if (dist > 3.5) continue;

            var toPlayer = player.method_19538().method_1020(living.method_19538()).method_1029();
            double dot = living.method_5720().method_1026(toPlayer);

            // Close + facing us + swinging = attacking
            if (dist <= 3.0 && dot > 0.3 && living.field_6252 && dist < bestDist) {
                bestDist = dist;
                best = living;
            }
        }
        return best;
    }

    private class_1309 findNearbyEnemy(class_310 client) {
        var player = client.field_1724;
        var box = player.method_5829().method_1014(4.0);
        class_1309 best = null;
        double bestDist = Double.MAX_VALUE;

        for (var entity : client.field_1687.method_8333(player, box,
                e -> e instanceof class_1309 && e.method_5805()
                        && (e instanceof class_1588 || e instanceof class_1657) && e != player)) {
            if (!(entity instanceof class_1309 living)) continue;
            double dist = living.method_5739(player);
            if (dist <= 4.0 && dist < bestDist) {
                bestDist = dist;
                best = living;
            }
        }
        return best;
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled();
    }

    @Override
    public void onDisable() {
        reset();
    }
}