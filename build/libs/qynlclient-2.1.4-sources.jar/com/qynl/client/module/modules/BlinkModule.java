package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2535;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_5819;

/**
 * Blink — holds movement packets briefly then releases them all at once.
 * Breaks the opponent's combo by making you appear to teleport.
 *
 * <p>Two modes:</p>
 * <ul>
 *   <li><b>Hold</b> — press the key to hold, release to burst.</li>
 *   <li><b>Auto</b> — automatically holds and releases in bursts with
 *       randomized timing. Hardened with burst fake lag (never a constant rate)
 *       and only activates on the ground while moving.</li>
 * </ul>
 */public class BlinkModule extends Module {
	private static final class_5819 RANDOM = class_5819.method_43047();
	private static BlinkModule instance;

	/** Movement packets currently held by Blink, flushed on release. */
	private static final List<class_2828> heldPackets = new ArrayList<>();

	private boolean holding = false;
    private int autoTimer = 0;
    private int holdDuration = 0;
    private int gapTicks = 0;	public BlinkModule() {
		super("Blink", "Holds movement packets and releases in bursts — breaks enemy combos.",
				Category.UTILITY);
		instance = this;
        bindKey(GLFW.GLFW_KEY_UNKNOWN);
        addSetting(Setting.options("mode", "Mode", "Auto", "Auto", "Hold"));
        addSetting(Setting.range("holdMs", "Hold duration", 400.0, 100, 1000, 50, "ms"));
        addSetting(Setting.range("gapMs", "Gap between", 600.0, 200, 1200, 50, "ms"));
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            if (holding) flushPackets(client);
            return;
        }
        var player = client.field_1724;

        String mode = getStringSetting("mode");

        if ("Hold".equals(mode)) {
            // Manual hold: press keybind to toggle
            holding = true;
            // Blink is released when module is toggled off (onDisable)
            return;
        }

        // Auto mode
        if (player.method_29504() || player.method_5799() || player.method_5771()
                || player.method_6101() || client.field_1755 != null) {
            holding = false;
            autoTimer = 0;
            holdDuration = 0;
            gapTicks = 0;
            return;
        }

        // Only blink on ground while moving
        if (!player.method_24828()) {
            holding = false;
            return;
        }
        double dx = player.method_23317() - player.field_6038;
        double dz = player.method_23321() - player.field_5989;
        if (dx * dx + dz * dz < 0.0001) {
            holding = false;
            return;
        }

        if (holding) {
            holdDuration--;
            if (holdDuration <= 0) {
                // Release burst — flush held packets
                flushPackets(client);
                holding = false;
                gapTicks = (int) Math.round(getDoubleSetting("gapMs") / 50.0)
                        + RANDOM.method_43048(Math.max(1, (int) Math.round(getDoubleSetting("gapMs") / 100.0)));
            }
            return;
        }

        if (gapTicks > 0) {
            gapTicks--;
            return;
        }

        // Start new hold
        holding = true;
        holdDuration = (int) Math.round(getDoubleSetting("holdMs") / 50.0)
                + RANDOM.method_43048(6) - 3;
        if (holdDuration < 2) holdDuration = 2;
    }	public boolean isHolding() {
		return isEnabled() && holding;
	}

	public static boolean isActive() {
		return instance != null && instance.isEnabled();
	}

	/** True while Blink is enabled and in a hold window — called by the send mixin. */
	public static boolean shouldHold() {
		return instance != null && instance.isHolding();
	}

	/** Add a movement packet to the hold buffer (called by the send mixin). */
	public static void buffer(class_2828 packet) {
		heldPackets.add(packet);
	}

	/** Flush all held packets through the given connection. */
	public static void releasePackets(class_2535 connection) {
		if (heldPackets.isEmpty()) return;
		for (class_2828 pkt : heldPackets) {
			connection.method_10752(pkt, null);
		}
		heldPackets.clear();
	}

    private void flushPackets(class_310 client) {
        if (client.method_1562() != null && client.method_1562().method_48296() != null) {
            releasePackets(client.method_1562().method_48296());
        }
    }

    @Override
    public void onDisable() {
        class_310 client = class_310.method_1551();
        flushPackets(client);
        holding = false;
        autoTimer = 0;
        holdDuration = 0;
        gapTicks = 0;
    }
}