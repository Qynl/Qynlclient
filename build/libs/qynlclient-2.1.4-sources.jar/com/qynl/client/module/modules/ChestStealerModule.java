package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1733;
import net.minecraft.class_1735;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

/**
 * ChestStealer — grabs every item from a chest for you with a single open.
 * Helps players who find click-dragging stacks into their inventory
 * difficult or tiring; just open a chest and it empties itself.
 */
public class ChestStealerModule extends Module {
	private static final int CLICK_DELAY = 3;
	private int cooldown = 0;

	public ChestStealerModule() {
		super("ChestStealer", "Open a chest and it automatically takes everything for you.",
				Category.UTILITY);
		// No default key — T was a constant accidental-toggle source. Bind it
		// yourself in Keybinds if you want a quick key.
		bindKey(GLFW.GLFW_KEY_UNKNOWN);
	}

	@Override
	public void onTick(class_310 client) {
		if (client.field_1724 == null || client.field_1761 == null) {
			return;
		}
		boolean isChest = client.field_1724.field_7512 instanceof class_1707
				|| client.field_1724.field_7512 instanceof class_1733;
		if (!isChest || client.field_1724.method_29504()) {
			cooldown = 0;
			return;
		}
		if (cooldown > 0) {
			cooldown--;
			return;
		}

		var menu = client.field_1724.field_7512;
		// Chests append their slots before the player's 36 inventory slots.
		int chestSlots = menu.field_7761.size() - 36;
		if (chestSlots <= 0) {
			return;
		}
		for (int i = 0; i < chestSlots; i++) {
			class_1735 slot = menu.method_7611(i);
			if (slot.method_7681()) {
				client.field_1761.method_2906(menu.field_7763, i, 0, class_1713.field_7794, client.field_1724);
				cooldown = CLICK_DELAY;
				return;
			}
		}
	}
}
