package com.qynl.client.module.modules;

import com.qynl.client.QynlClient;
import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.ModuleManager;
import com.qynl.client.module.Setting;
import com.qynl.client.util.PingTracker;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_2596;
import net.minecraft.class_310;
import net.minecraft.class_3532;

/**
 * ReachAssist — extends reach with natural, humanized fluctuation, tuned to
 * stay inside the "ghost" range modern anti-cheat (Grim / Vulcan) tolerates.
 *
 * <p>The per-mode bounds keep the total reach between 3.01 and 3.35 blocks,
 * which reads as connection jitter instead of reach abuse.</p>
 *
 * <p>On top of the small bonus, the optional <b>Silent Pack-Choke</b> applies
 * the backtrack principle: while you are in combat and closing on an enemy
 * 3.0–3.6 blocks away, outgoing movement packets are held for 1–2 server
 * ticks and then flushed together. The server resolves your position further
 * ahead than the opponent sees, so hits register from what looks like 3.5
 * blocks while the anti-cheat sees you mathematically inside 3.0. It is the
 * same fake-lag trick as {@link BlinkModule} and carries the same server
 * tolerance caveats.</p>
 */
public class ReachAssistModule extends Module {
    private static final Random RANDOM = new Random();
    private static double currentBonus = 0.12;
    private static double minBonus = 0.05, maxBonus = 0.18;
    private double targetBonus = 0.12;
    private int walkTimer = 0;
    private int transitionTimer = 0;

    // ── Silent Pack-Choke state ─────────────────────────────────
    private static final int MAX_CHOKE = 8;
    private static final Deque<class_2596<?>> chokeQueue = new ArrayDeque<>();
    private static boolean armed = false;
    private static int holdTicksLeft = 0;
    private static int cooldownTicks = 0;
    private static boolean flushing = false;

    public ReachAssistModule() {
        super("ReachAssist",
                "Extends reach with smooth, human-like fluctuation. Optional Silent Pack-Choke for ghost servers.",
                Category.COMBAT);
        bindKey(GLFW.GLFW_KEY_I);
        addSetting(Setting.options("mode",        "Mode",        "Normal", "Subtle", "Normal", "Aggressive"));
        addSetting(Setting.options("fluctuation", "Fluctuation", "Medium", "Low", "Medium", "High"));
        addSetting(Setting.options("choke",       "Pack choke",  "On",     "Off", "On"));
    }

    @Override
    public void onEnable() { applyBounds(); }

    @Override
    public void onTick(class_310 client) {
        applyBounds();

        int interval;
        double flucRange;
        switch (getStringSetting("fluctuation")) {
            case "Low":  interval = 7; flucRange = 0.06; break;
            case "High": interval = 3; flucRange = 0.20; break;
            default:     interval = 5; flucRange = 0.12; break;
        }

        if (--walkTimer <= 0) {
            walkTimer = interval + RANDOM.nextInt(interval);
            targetBonus = minBonus + RANDOM.nextDouble() * (maxBonus - minBonus);
            transitionTimer = interval;
        }

        // Smoothly interpolate toward target for natural feel
        if (transitionTimer > 0) {
            transitionTimer--;
            double t = 1.0 - (double) transitionTimer / (walkTimer + 1);
            t = t * t * (3.0 - 2.0 * t); // smoothstep
            double prevBonus = currentBonus;
            currentBonus = prevBonus + (targetBonus - prevBonus) * t * 0.5;
        }

        currentBonus = class_3532.method_15350(currentBonus, minBonus, maxBonus);

        tickChoke(client);
    }

    /**
     * Per-mode reach bonus bounds. These keep the total reach inside the
     * ghost range (3.01–3.35 blocks) so no anti-cheat reach check can ever
     * call it impossible.
     */
    private void applyBounds() {
        switch (getStringSetting("mode")) {
            case "Subtle":     minBonus = 0.01; maxBonus = 0.08; break; // 3.01–3.08 (Grim safe)
            case "Aggressive": minBonus = 0.15; maxBonus = 0.35; break; // 3.15–3.35 (Vulcan/Matrix limit)
            default:           minBonus = 0.05; maxBonus = 0.18; break; // 3.05–3.18 (Hypixel safe)
        }
        currentBonus = class_3532.method_15350(currentBonus, minBonus, maxBonus);
        targetBonus = class_3532.method_15350(targetBonus, minBonus, maxBonus);
    }

    // ── Silent Pack-Choke ───────────────────────────────────────

    /** True while the choke is actively holding packets (used by other
     *  modules to avoid colliding with the choke window). */
    public static boolean isChokeArmed() {
        return armed && !flushing;
    }

    /** True while the choke is armed and the packet should be held back. */
    public static boolean shouldHoldPacket() {
        return armed && !flushing && !BlinkModule.isActive() && chokeQueue.size() < MAX_CHOKE;
    }

    /** Buffers one held movement packet (called from the send mixin). */
    public static void buffer(class_2596<?> packet) {
        if (chokeQueue.size() < MAX_CHOKE) {
            chokeQueue.addLast(packet);
        }
    }

    /** Sends every buffered packet through the normal send path. */
    public static void flush(class_310 client) {
        if (client == null || client.method_1562() == null
                || client.method_1562().method_48296() == null) {
            chokeQueue.clear();
            return;
        }
        flushing = true;
        try {
            class_2596<?> packet;
            while ((packet = chokeQueue.pollFirst()) != null) {
                client.method_1562().method_48296().method_10743(packet);
            }
        } finally {
            flushing = false;
        }
    }

    /**
     * Arms / maintains / flushes the choke window once per client tick.
     */
    private void tickChoke(class_310 client) {
        if (!"On".equals(getStringSetting("choke"))) {
            flush(client);
            armed = false;
            holdTicksLeft = 0;
            return;
        }
        if (client.field_1724 == null || client.field_1687 == null || !client.field_1724.method_5805()) {
            flush(client);
            armed = false;
            holdTicksLeft = 0;
            return;
        }
        // On high ping the held packets turn into a bigger server-side
        // catch-up jump — exactly the rubberband signature Grim's movement
        // check flags. The choke only buys reach when the connection is
        // tight enough to stay subtle.
        if (PingTracker.hasPing() && PingTracker.getPingMs() > 150) {
            armed = false;
            holdTicksLeft = 0;
            return;
        }

        if (armed) {
            if (--holdTicksLeft <= 0) {
                flush(client);
                armed = false;
                cooldownTicks = 8 + RANDOM.nextInt(7); // 8–14 tick gap between chokes
            }
        } else if (cooldownTicks > 0) {
            cooldownTicks--;
        } else if (inChokeWindow(client)) {
            armed = true;
            holdTicksLeft = 1 + RANDOM.nextInt(2); // 1–2 server ticks (50–100 ms)
        }
    }

    /**
     * True while the player is in combat and closing on an enemy that sits
     * 3.0–3.6 blocks away — the window where the choke buys reach.
     */
    private boolean inChokeWindow(class_310 client) {
        if (!client.field_1690.field_1886.method_1434()) return false; // in combat
        if (!client.field_1724.method_24828()) return false;

        class_1309 target = findChokeTarget(client);
        if (target == null) return false;

        double dx = target.method_23317() - client.field_1724.method_23317();
        double dy = target.method_23318() - client.field_1724.method_23318();
        double dz = target.method_23321() - client.field_1724.method_23321();
        double distSq = dx * dx + dy * dy + dz * dz;
        if (distSq < 3.0 * 3.0 || distSq > 3.6 * 3.6) return false;

        // Only while running toward the target — never while backing away.
        if (client.field_1724.field_3913 == null || client.field_1724.field_3913.field_3905 <= 0.0F) return false;
        // Never choke while sprinting: the held packets cover more distance
        // at sprint speed, so the flush becomes a visibly larger catch-up
        // jump — the exact rubberband signature Grim's movement check flags.
        if (client.field_1724.method_5624()) return false;
        double vx = client.field_1724.method_23317() - client.field_1724.field_6038;
        double vz = client.field_1724.method_23321() - client.field_1724.field_5989;
        return vx * dx + vz * dz > 0;
    }

    /** Nearest attackable enemy within 4 blocks. */
    private class_1309 findChokeTarget(class_310 client) {
        double rangeSq = 4.0 * 4.0;
        class_1309 best = null;
        double bestDistSq = Double.MAX_VALUE;

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1309)) continue;
            class_1309 living = (class_1309) entity;
            if (living == client.field_1724 || !living.method_5805()) continue;
            if (!(living instanceof class_1588 || living instanceof class_1657)) continue;
            if (FriendsModule.isFriend(FriendsModule.entityName(living))) continue;

            double dx = living.method_23317() - client.field_1724.method_23317();
            double dy = living.method_23318() - client.field_1724.method_23318();
            double dz = living.method_23321() - client.field_1724.method_23321();
            double distSq = dx * dx + dy * dy + dz * dz;
            if (distSq < bestDistSq && distSq <= rangeSq) {
                bestDistSq = distSq;
                best = living;
            }
        }
        return best;
    }

    /** Central world-change/death hook: drain held packets immediately. */
    @Override
    public void onWorldChange(class_310 client) {
        flush(client);
        armed = false;
        holdTicksLeft = 0;
    }

    @Override
    public void onDisable() {
        // Never leave the player frozen: flush whatever is buffered.
        class_310 client = class_310.method_1551();
        flush(client);
        armed = false;
        holdTicksLeft = 0;
    }

    public static double currentBonus() { return currentBonus; }
    public static boolean isActive() {
        class_310 client = class_310.method_1551();
        if (client == null) return false;
        QynlClient qynl = QynlClient.getInstance();
        if (qynl == null) return false;
        ModuleManager modules = qynl.getModuleManager();
        return modules != null && modules.isEnabled("ReachAssist");
    }
}
