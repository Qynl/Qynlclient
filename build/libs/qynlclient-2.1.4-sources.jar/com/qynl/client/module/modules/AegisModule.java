package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import net.minecraft.class_1667;
import net.minecraft.class_1676;
import net.minecraft.class_1680;
import net.minecraft.class_1681;
import net.minecraft.class_1684;
import net.minecraft.class_1686;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.world.entity.projectile.*;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Aegis — The Evasion Engine.
 *
 * <p>Integrates every projectile's trajectory (arrows, snowballs, splash pots,
 * pearls) against your own motion and sidesteps out of the way with pure
 * vanilla input. Dodge direction is the weighted vector sum of all inbound
 * projectiles — one decisive strafe, never a nervous flicker.</p>
 */
public class AegisModule extends Module {
    private static final class_5819 RANDOM = class_5819.method_43047();

    private boolean dodging = false;
    private int dodgeTimer = 0;
    private int cooldownTicks = 0;
    private double dodgeX = 0;
    private double dodgeZ = 0;

    public AegisModule() {
        super("Aegis", "Evasion Engine — dodges arrows, snowballs, and projectiles with weighted vector sidesteps.",
                Category.COMBAT);
        bindKey(GLFW.GLFW_KEY_UNKNOWN);
        addSetting(Setting.range("reactionMs", "Reaction delay", 100.0, 50, 250, 10, "ms"));
        addSetting(Setting.range("dodgeDist", "Dodge distance", 2.5, 1.5, 4.0, 0.25, "b"));
        addSetting(Setting.range("cooldownMs", "Cooldown", 200.0, 100, 500, 50, "ms"));
        addSetting(Setting.options("voidGuard", "Void guard", "On", "On", "Off"));
        addSetting(Setting.range("inaccuracy", "Human inaccuracy", 15.0, 0, 30, 5, "%"));
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            reset();
            return;
        }
        var player = client.field_1724;
        if (player.method_29504() || player.method_7325() || player.method_5765()) {
            reset();
            return;
        }

        if (cooldownTicks > 0) cooldownTicks--;

        if (dodging) {
            if (dodgeTimer > 0) {
                dodgeTimer--;
                // Maintain dodge direction
                return;
            }
            // Dodge complete — release keys
            releaseDodge(client);
            cooldownTicks = (int) Math.round(getDoubleSetting("cooldownMs") / 50.0) + RANDOM.method_43048(4);
            return;
        }

        if (cooldownTicks > 0) return;

        // Scan for inbound projectiles
        List<ProjectileDanger> dangers = scanProjectiles(client);
        if (dangers.isEmpty()) return;

        // Void guard: don't dodge into the void
        if ("On".equals(getStringSetting("voidGuard")) && isNearVoid(client)) return;

        // Compute weighted dodge direction
        double totalX = 0, totalZ = 0;
        double totalWeight = 0;
        class_243 myPos = player.method_19538();

        for (ProjectileDanger d : dangers) {
            class_243 toMe = myPos.method_1020(d.pos);
            double dist = toMe.method_1033();
            if (dist < 0.01) continue;
            double weight = 1.0 / Math.max(0.5, dist) * d.threat;
            totalX += toMe.field_1352 / dist * weight;
            totalZ += toMe.field_1350 / dist * weight;
            totalWeight += weight;
        }

        if (totalWeight < 0.001) return;

        // Normalize
        double len = Math.sqrt(totalX * totalX + totalZ * totalZ);
        if (len < 0.001) return;

        // Apply human inaccuracy
        double inaccuracy = getDoubleSetting("inaccuracy") / 100.0;
        double angle = (RANDOM.method_43058() - 0.5) * inaccuracy * Math.PI;
        double cos = Math.cos(angle), sin = Math.sin(angle);
        double nx = totalX / len * cos - totalZ / len * sin;
        double nz = totalX / len * sin + totalZ / len * cos;

        // Start dodge
        dodgeX = nx;
        dodgeZ = nz;
        dodging = true;
        dodgeTimer = (int) Math.round(getDoubleSetting("dodgeDist") / 0.3); // ticks based on move speed
        if (dodgeTimer < 2) dodgeTimer = 2;
        if (dodgeTimer > 12) dodgeTimer = 12;
    }	/** Called by InputMixin to apply dodge direction. */
	public boolean isDodging() {
        return isEnabled() && dodging;
    }

    public double getForwardDodge() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return 0;
        float yawRad = (float) Math.toRadians(client.field_1724.method_36454());
        double forwardX = -Math.sin(yawRad);
        double forwardZ = Math.cos(yawRad);
        return dodgeX * forwardX + dodgeZ * forwardZ;
    }

    public double getStrafeDodge() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return 0;
        float yawRad = (float) Math.toRadians(client.field_1724.method_36454());
        double strafeX = Math.cos(yawRad);
        double strafeZ = Math.sin(yawRad);
        return dodgeX * strafeX + dodgeZ * strafeZ;
    }

    private void releaseDodge(class_310 client) {
        dodging = false;
        dodgeTimer = 0;
        dodgeX = 0;
        dodgeZ = 0;
    }

    private void reset() {
        class_310 client = class_310.method_1551();
        releaseDodge(client);
        cooldownTicks = 0;
    }

    private List<ProjectileDanger> scanProjectiles(class_310 client) {
        List<ProjectileDanger> dangers = new ArrayList<>();
        class_238 scanBox = client.field_1724.method_5829().method_1014(getDoubleSetting("dodgeDist") + 2.0);

        for (class_1676 proj : client.field_1687.method_8390(class_1676.class, scanBox,
                e -> e.method_5805())) {
            if (proj.method_24921() == client.field_1724) continue; // don't dodge own projectiles

            class_243 pos = proj.method_19538();
            class_243 vel = proj.method_18798();
            if (vel.method_1027() < 0.001) continue;

            // Check if projectile is heading roughly toward us
            class_243 toPlayer = client.field_1724.method_19538().method_1020(pos);
            double dot = vel.method_1029().method_1026(toPlayer.method_1029());
            if (dot < 0.3) continue; // not heading toward us

            double threat = 1.0;
            if (proj instanceof class_1667) threat = 2.0;
            else if (proj instanceof class_1681 || proj instanceof class_1680) threat = 0.5;
            else if (proj instanceof class_1686 || proj instanceof class_1684) threat = 0.3;

            dangers.add(new ProjectileDanger(pos, threat));
        }
        return dangers;
    }

    private boolean isNearVoid(class_310 client) {
        return client.field_1724.method_23318() < client.field_1724.method_37908().method_31607() + 8;
    }

    private record ProjectileDanger(class_243 pos, double threat) {}

    @Override
    public void onDisable() {
        reset();
    }
}