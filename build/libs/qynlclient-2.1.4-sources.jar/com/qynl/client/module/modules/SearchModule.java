package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_761;

/**
 * Search — outlines configured blocks through walls.
 * Cached scan with distance-based updates.
 */
public class SearchModule extends Module {
    private static SearchModule instance;

    private final Map<class_2338, Long> cachedBlocks = new ConcurrentHashMap<>();
    private int scanTimer = 0;
    private class_2338 lastPlayerPos = class_2338.field_10980;

    // Block types to search for
    private static final List<String> BLOCK_TYPES = List.of(
            "Chests", "Ores", "Storage", "Spawners", "Portals", "Vaults"
    );

    public SearchModule() {
        super("Search", "Outlines chests, ores, and storage blocks through walls (cached scan).",
                Category.RENDER);
        instance = this;
        bindKey(GLFW.GLFW_KEY_UNKNOWN);
        addSetting(Setting.options("blocks", "Search for", "Ores", BLOCK_TYPES.toArray(new String[0])));
        addSetting(Setting.range("radius", "Scan radius", 64.0, 16, 128, 8, "b"));
        addSetting(Setting.range("opacity", "Opacity", 40.0, 10, 100, 5, "%"));
    }

    public static SearchModule getInstance() { return instance; }

    public void render(class_4587 poseStack, class_4597 bufferSource, class_243 camPos) {
        if (!isEnabled() || cachedBlocks.isEmpty()) return;

        String blockType = getStringSetting("blocks");
        int alpha = (int) (getDoubleSetting("opacity") / 100.0 * 255);
        int color = switch (blockType) {
            case "Chests" -> 0xFFFFAA00;
            case "Storage" -> 0xFF00AAFF;
            case "Spawners" -> 0xFFFF4444;
            case "Portals" -> 0xFFAA00FF;
            case "Vaults" -> 0xFF4444FF;
            default -> 0xFFFFFF00; // Ores
        };

        class_4588 consumer = bufferSource.getBuffer(class_1921.method_23594());
        Matrix4f matrix = poseStack.method_23760().method_23761();

        long now = System.currentTimeMillis();
        cachedBlocks.entrySet().removeIf(e -> now - e.getValue() > 10000);

        for (class_2338 pos : cachedBlocks.keySet()) {
            class_243 renderPos = class_243.method_24954(pos).method_1020(camPos);
            class_238 box = new class_238(renderPos.field_1352, renderPos.field_1351, renderPos.field_1350,
                    renderPos.field_1352 + 1, renderPos.field_1351 + 1, renderPos.field_1350 + 1);

            class_761.method_22982(poseStack, consumer, box,
                    (color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF, alpha);
        }
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        scanTimer++;
        class_2338 currentPos = client.field_1724.method_24515();

        // Only rescan when player moves significantly or timer fires
        if (scanTimer < 20 && currentPos.method_10262(lastPlayerPos) < 64) return;
        scanTimer = 0;
        lastPlayerPos = currentPos;

        int radius = (int) getDoubleSetting("radius");
        String blockType = getStringSetting("blocks");
        class_1937 level = client.field_1687;

        // Clear old cache beyond radius
        cachedBlocks.entrySet().removeIf(e -> e.getKey().method_10262(currentPos) > radius * radius);

        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    class_2338 pos = currentPos.method_10069(x, y, z);
                    if (cachedBlocks.containsKey(pos)) continue;
                    if (!level.method_8477(pos)) continue;

                    class_2680 state = level.method_8320(pos);
                    if (isTargetBlock(state, blockType)) {
                        cachedBlocks.put(pos.method_10062(), System.currentTimeMillis());
                    }
                }
            }
        }
    }

    private boolean isTargetBlock(class_2680 state, String type) {
        String name = state.method_26204().method_9539();
        return switch (type) {
            case "Ores" -> name.contains("ore") || name.contains("diamond") || name.contains("emerald")
                    || name.contains("gold") || name.contains("iron") || name.contains("coal")
                    || name.contains("copper") || name.contains("redstone") || name.contains("lapis")
                    || name.contains("netherite") || name.contains("ancient_debris");
            case "Chests" -> name.contains("chest") || name.contains("barrel");
            case "Storage" -> name.contains("chest") || name.contains("barrel")
                    || name.contains("shulker") || name.contains("furnace")
                    || name.contains("hopper") || name.contains("dispenser") || name.contains("dropper");
            case "Spawners" -> name.contains("spawner");
            case "Portals" -> name.contains("portal");
            case "Vaults" -> name.contains("vault");
            default -> false;
        };
    }

    @Override
    public void onDisable() {
        cachedBlocks.clear();
        scanTimer = 0;
    }
}