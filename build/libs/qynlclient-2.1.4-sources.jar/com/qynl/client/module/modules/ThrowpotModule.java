package com.qynl.client.module.modules;

import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1844;
import net.minecraft.class_310;
import net.minecraft.class_6880;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;

/**
 * Throwpot — press the bind to throw/drink/eat your best healing item.
 * Prioritizes splash potions of healing, then regeneration, then food.
 */
public class ThrowpotModule extends Module {
    private boolean used = false;
    /** Ticks the use key is held after triggering (food/drinkables). */
    private int useHoldTicks = 0;

    public ThrowpotModule() {
        super("Throwpot", "Press the bind to throw/drink/eat your best healing item instantly.",
                Category.UTILITY);
        bindKey(GLFW.GLFW_KEY_UNKNOWN);
        addSetting(Setting.range("healthPct", "Use below", 60.0, 20, 90, 5, "%"));
    }

    @Override
    public void onEnable() {
        used = false;
        useHoldTicks = 0;
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null) {
            used = false;
            return;
        }
        var player = client.field_1724;
        if (player.method_29504() || player.method_7325() || player.method_7337()) {
            used = false;
            return;
        }		// Release the use key a couple of seconds after triggering so it is
		// never left logically held (which would hijack the player's right-click).
		if (useHoldTicks > 0) {
			if (--useHoldTicks <= 0) {
				client.field_1690.field_1904.method_23481(false);
			}
			return;
		}

		if (used) return;

		float healthPct = player.method_6032() / player.method_6063() * 100f;
        if (healthPct > getDoubleSetting("healthPct")) return;

        class_1661 inv = player.method_31548();
        int bestSlot = -1;
        float bestScore = 0;

        // 1. Splash/lingering healing potions (best)
        for (int i = 0; i < 9; i++) {
            class_1799 stack = inv.method_5438(i);
            float score = healingScore(stack);
            if (score > bestScore) {
                bestScore = score;
                bestSlot = i;
            }
        }

        if (bestSlot < 0) {
            // 2. Try food as fallback
            for (int i = 0; i < 9; i++) {
                class_1799 stack = inv.method_5438(i);
                var food = stack.method_57824(class_9334.field_50075);
                if (food != null) {
                    float score = food.comp_2491() + food.comp_2492() * 2;
                    if (score > bestScore) {
                        bestScore = score;
                        bestSlot = i;
                    }
                }
            }
        }

        if (bestSlot < 0) return;

        int prevSlot = inv.field_7545;
        if (inv.field_7545 != bestSlot) {
            inv.field_7545 = bestSlot;
        }

        // Use the item
        class_1799 toUse = player.method_6047();
        boolean isThrowable = toUse.method_57824(class_9334.field_49651) != null;

        if (isThrowable) {
            client.field_1761.method_2919(player, class_1268.field_5808);
            // For throwable potions, this throws immediately
            inv.field_7545 = prevSlot;		} else {
			// For food/drinkable, hold use to consume — released after ~1.6 s.
			client.field_1690.field_1904.method_23481(true);
			useHoldTicks = 32;
		}

		used = true;
	}

    private float healingScore(class_1799 stack) {
        class_1844 contents = stack.method_57824(class_9334.field_49651);
        if (contents == null) return 0;

        float score = 0;
        for (class_1293 effect : contents.method_57397()) {
            class_6880<class_1291> holder = effect.method_5579();
            class_1291 value = holder.comp_349();
            if (value == class_1294.field_5915.comp_349()) {
                score += 20 * (effect.method_5578() + 1);
            } else if (value == class_1294.field_5924.comp_349()) {
                score += 10 * (effect.method_5578() + 1);
            } else if (value == class_1294.field_5898.comp_349()) {
                score += 8 * (effect.method_5578() + 1);
            }
        }
        return score;
    }	@Override
	public void onDisable() {
		used = false;
		useHoldTicks = 0;
		class_310 client = class_310.method_1551();
		if (client.field_1690 != null) {
			client.field_1690.field_1904.method_23481(false);
		}
	}
}