package com.qynl.client.module.modules;

import com.qynl.client.Friends;
import com.qynl.client.module.Category;
import com.qynl.client.module.Module;
import com.qynl.client.module.Setting;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

/**
 * NameTags — renders entity nametags through walls.
 * Friends green, enemies red, mobs yellow.
 */
public class NameTagsModule extends Module {
    private static NameTagsModule instance;

    public NameTagsModule() {
        super("NameTags", "Renders entity nametags through walls — friends green, enemies red.",
                Category.RENDER);
        instance = this;
        bindKey(GLFW.GLFW_KEY_UNKNOWN);
        addSetting(Setting.range("maxDist", "Max distance", 64.0, 16, 128, 8, "b"));
        addSetting(Setting.range("scale", "Scale", 1.0, 0.5, 2.0, 0.1));
        addSetting(Setting.options("showHealth", "Show health", "On", "On", "Off"));
    }

    public static NameTagsModule getInstance() { return instance; }

    public void render(class_4587 poseStack, class_4597 bufferSource, class_243 camPos) {
        if (!isEnabled()) return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        double maxDist = getDoubleSetting("maxDist");
        double scale = getDoubleSetting("scale");
        boolean showHealth = "On".equals(getStringSetting("showHealth"));
        class_327 font = client.field_1772;
        class_243 playerEye = client.field_1724.method_33571();

        for (var entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1309 living)) continue;
            if (entity == client.field_1724) continue;
            if (!(entity instanceof class_1657 || entity instanceof class_1588)) continue;
            if (!living.method_5805()) continue;

            class_243 entityPos = entity.method_33571();
            double dist = playerEye.method_1022(entityPos);
            if (dist > maxDist) continue;

            class_243 renderPos = entityPos.method_1020(camPos);

            int color;
            String name;
            if (entity instanceof class_1657 player) {
                name = player.method_5477().getString();
                color = Friends.isFriend(name) ? 0xFF55FF55 : 0xFFFF5555;
            } else {
                name = entity.method_5477().getString();
                color = 0xFFFFAA00;
            }

            if (showHealth && living instanceof class_1309 le) {
                name += " " + String.format("%.0f", le.method_6032()) + "HP";
            }

            poseStack.method_22903();
            poseStack.method_22904(renderPos.field_1352, renderPos.field_1351 + 0.5, renderPos.field_1350);
            poseStack.method_22907(client.field_1773.method_19418().method_23767());
            poseStack.method_22905((float) (-0.025 * scale), (float) (-0.025 * scale), (float) (0.025 * scale));

            Matrix4f matrix = poseStack.method_23760().method_23761();
            float bgOpacity = 0.5f;
            int width = font.method_1727(name) / 2;
            font.method_30882(class_2561.method_43470(name),
                    -width, -4, color, false, matrix, bufferSource,
                    class_327.class_6415.field_33994,
                    (int) (bgOpacity * 255) << 24, 0xF000F0);
            font.method_30882(class_2561.method_43470(name),
                    -width, -4, color, false, matrix, bufferSource,
                    class_327.class_6415.field_33993, 0, 0xF000F0);

            poseStack.method_22909();
        }
    }
}