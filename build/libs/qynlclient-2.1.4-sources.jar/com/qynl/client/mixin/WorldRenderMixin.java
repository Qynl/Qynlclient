package com.qynl.client.mixin;

import com.qynl.client.module.modules.DirectorModule;
import com.qynl.client.module.modules.EchoModule;
import com.qynl.client.module.modules.NameTagsModule;
import com.qynl.client.module.modules.QynlModule;
import com.qynl.client.module.modules.SearchModule;
import com.qynl.client.module.modules.StorageESPModule;
import com.qynl.client.module.modules.TracersModule;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Renders 3D ESP overlays (Qynl, Director, Search, StorageESP, Tracers,
 * NameTags, Echo) at the end of the level render pass.
 *
 * <p>1.21.1 signature: {@code LevelRenderer.renderLevel(DeltaTracker, boolean,
 * Camera, GameRenderer, LightTexture, Matrix4f, Matrix4f)} — note the PoseStack
 * was removed from the method in 1.21, so the camera-rotated model matrix is
 * rebuilt here for world-space overlays.</p>
 */
@Mixin(class_761.class)
public abstract class WorldRenderMixin {

    @Shadow @Final private class_310 minecraft;

    @Inject(method = "renderLevel", at = @At("TAIL"))
    private void qynlclient$renderESP(class_9779 deltaTracker, boolean renderBlockOutline,
                                      class_4184 camera, class_757 gameRenderer,
                                      class_765 lightTexture, Matrix4f projectionMatrix,
                                      Matrix4f frustumMatrix, CallbackInfo ci) {
        if (minecraft.field_1724 == null || minecraft.field_1687 == null) return;

        class_4597.class_4598 bufferSource = minecraft.method_22940().method_23000();
        class_243 camPos = camera.method_19326();

        // Camera-rotated model matrix for world-space boxes / lines (the same
        // matrix vanilla builds inside renderLevel for block outlines).
        class_4587 worldStack = new class_4587();
        worldStack.method_22907(camera.method_23767());

        // Render the flagship quantum overlay (Qynl) and the Director focus ring.
        QynlModule.render(worldStack, bufferSource, camPos);
        DirectorModule.render(worldStack, bufferSource, camPos);

        // Render ESP modules
        SearchModule search = SearchModule.getInstance();
        if (search != null) search.render(worldStack, bufferSource, camPos);

        StorageESPModule storage = StorageESPModule.getInstance();
        if (storage != null) storage.render(worldStack, bufferSource, camPos);

        TracersModule tracers = TracersModule.getInstance();
        if (tracers != null) tracers.render(worldStack, bufferSource, camPos);

        // NameTags builds its own billboard transform (translate → face camera → scale),
        // so it needs an identity pose stack to start from.
        NameTagsModule nameTags = NameTagsModule.getInstance();
        if (nameTags != null) nameTags.render(new class_4587(), bufferSource, camPos);

        // Echo markers
        EchoModule echo = EchoModule.getInstance();
        if (echo != null && echo.isEnabled()) {
            for (EchoModule.EchoMarker marker : echo.getMarkers()) {
                long elapsed = System.currentTimeMillis() - marker.timestamp();
                double fadeMs = echo.getDoubleSetting("fadeMs");
                float alpha = 1.0f - Math.min(1.0f, (float) elapsed / (float) fadeMs);
                if (alpha <= 0) continue;

                class_243 renderPos = marker.pos().method_1020(camPos);
                int color = marker.color();
                int drawColor = color | ((int) (alpha * 255) << 24);

                minecraft.field_1772.method_30882(
                        class_2561.method_43470("\u25cf"),
                        (float) renderPos.field_1352 - 3, (float) renderPos.field_1351 - 3,
                        drawColor,
                        true, worldStack.method_23760().method_23761(), bufferSource,
                        net.minecraft.class_327.class_6415.field_33994,
                        0, 0xF000F0);
            }
        }

        bufferSource.method_22993();
    }
}
