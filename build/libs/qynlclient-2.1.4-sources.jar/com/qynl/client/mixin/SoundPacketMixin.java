package com.qynl.client.mixin;

import com.qynl.client.module.modules.EchoModule;
import net.minecraft.class_2767;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Forwards sound packets to the Echo module for soundscape radar.
 */
@Mixin(class_634.class)
public abstract class SoundPacketMixin {
    @Inject(method = "handleSoundEvent", at = @At("HEAD"))
    private void qynlclient$onSound(class_2767 packet, CallbackInfo ci) {
        EchoModule.onSoundPacket(packet);
    }
}