package com.qynl.client.mixin;	import com.qynl.client.QynlClient;
	import com.qynl.client.module.modules.AegisModule;
	import com.qynl.client.module.modules.QynlModule;
	import com.qynl.client.module.modules.StrafeAssistModule;
	import com.qynl.client.module.modules.WTapModule;
import net.minecraft.class_310;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Applies input overrides AFTER vanilla {@link class_744#method_3129} has read the
 * keyboard.
 */
@Mixin(class_744.class)
public abstract class InputMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void qynlclient$applyInputOverrides(boolean slowDown, float slowDownFactor, CallbackInfo ci) {
        class_744 input = (class_744) (Object) this;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }		// WTap — release forward for a tick after each hit (sprint reset).
		// Applied to the input, never to the W KeyMapping, so the player's
		// real keyboard state is untouched and forward resumes naturally.
		if (WTapModule.isTapping()) {
			input.field_3905 = 0;
		}

		// Qynl — Quantum Collapse dodge strafe (only while the dodge hold is
		// active; the player must already be moving, enforced by QynlModule).
		float dodge = QynlModule.dodgeStrafe();
        if (dodge != 0.0F) {
            // positive dodge = strafe right → negative leftImpulse
            input.field_3907 = -dodge;
        }

        // Aegis — evasion engine (projectile dodging).
        AegisModule aegis = (AegisModule) QynlClient.getInstance().getModuleManager().find("Aegis");
        if (aegis != null && aegis.isDodging()) {
            double forward = aegis.getForwardDodge();
            double strafe = aegis.getStrafeDodge();
            // Blend dodge with existing player input
            if (Math.abs(forward) > 0.1) {
                input.field_3905 = (float) Math.signum(forward);
            }
            if (Math.abs(strafe) > 0.1) {
                input.field_3907 = (float) -Math.signum(strafe);
            }
        }

        // StrafeAssist — auto-strafe in combat.
        StrafeAssistModule strafe = (StrafeAssistModule) QynlClient.getInstance().getModuleManager().find("StrafeAssist");
        if (strafe != null && strafe.isEnabled()) {
            if (strafe.shouldStrafeLeft()) {
                input.field_3907 = 1.0F;
                input.field_3905 = Math.max(0, input.field_3905);
            } else if (strafe.shouldStrafeRight()) {
                input.field_3907 = -1.0F;
                input.field_3905 = Math.max(0, input.field_3905);
            }
        }
    }
}
