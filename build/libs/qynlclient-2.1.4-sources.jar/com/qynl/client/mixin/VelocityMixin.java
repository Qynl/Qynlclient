package com.qynl.client.mixin;

import com.qynl.client.module.modules.VelocityAssistModule;
import net.minecraft.class_2743;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Gives VelocityAssist its effect: knockback (and similar hits) sent to the
 * local player are dampened by a percentage instead of being fully blocked.
 */
@Mixin(class_634.class)
public abstract class VelocityMixin {
	@Inject(method = "handleSetEntityMotion", at = @At("HEAD"), cancellable = true)
	private void qynlclient$dampKnockback(class_2743 packet, CallbackInfo ci) {
		class_310 client = class_310.method_1551();
		if (client.field_1724 == null || client.field_1724.method_5628() != packet.method_11818()) {
			return;
		}
		VelocityAssistModule module = VelocityAssistModule.getInstance();
		if (module == null || !module.isActive()) {
			return;
		}
		if (!VelocityAssistModule.rollChance()) {
			return; // this hit takes full knockback — human variance
		}
		double x = packet.method_11815() * module.horizontalFactor();
		double y = packet.method_11816() * module.verticalFactor();
		double z = packet.method_11819() * module.horizontalFactor();
		client.field_1724.method_18800(x, y, z);
		VelocityAssistModule.markMixinDampened();
		ci.cancel();
	}
}
