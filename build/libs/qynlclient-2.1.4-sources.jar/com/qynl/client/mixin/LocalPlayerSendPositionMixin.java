package com.qynl.client.mixin;

import com.qynl.client.util.SilentAim;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Packet-mode aim (silent aim) hook.
 *
 * <p>While {@link com.qynl.client.util.SilentAim} is armed, the movement
 * packet that is built inside {@code LocalPlayer.sendPosition()} carries the
 * silently-aimed rotation — so the server resolves attacks as if the player
 * were looking at the target — while the camera is restored to the player's
 * own view immediately afterwards.</p>
 */
@Mixin(class_746.class)
public abstract class LocalPlayerSendPositionMixin {
	@Inject(method = "sendPosition", at = @At("HEAD"))
	private void qynlclient$silentAimHead(CallbackInfo ci) {
		if (SilentAim.isArmed()) {
			class_746 self = (class_746) (Object) this;
			// Remember exactly where the player's camera really is right now, so
			// the TAIL hook can restore it without any visible snap.
			SilentAim.captureVisual(self.method_36454(), self.method_36455());
			self.method_36456(SilentAim.getSilentYaw());
			self.method_36457(SilentAim.getSilentPitch());
		}
	}

	@Inject(method = "sendPosition", at = @At("TAIL"))
	private void qynlclient$silentAimTail(CallbackInfo ci) {
		if (SilentAim.isArmed()) {
			class_746 self = (class_746) (Object) this;
			self.method_36456(SilentAim.getVisualYaw());
			self.method_36457(SilentAim.getVisualPitch());
		}
	}
}
