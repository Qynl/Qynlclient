package com.qynl.client.util;

import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_761;
import org.joml.Matrix4f;

/**
 * Small helper for world-space overlay drawing (Qynl / Director / Search /
 * StorageESP / Tracers / NameTags). All draws are camera-relative: pass the
 * camera position and emit vertices offset by it, then let the caller's
 * {@code bufferSource.endBatch()} flush the batch.
 */
public final class WorldDraw {

    private WorldDraw() {
    }

    /**
     * Draws a 12-edge wireframe box spanning an arbitrary AABB, camera-relative.
     */
    public static void drawAABB(class_4587 poseStack, class_4597 bufferSource, class_243 camPos,
                                double minX, double minY, double minZ,
                                double maxX, double maxY, double maxZ,
                                float r, float g, float b, float a) {
        class_4588 consumer = bufferSource.getBuffer(class_1921.method_23594());
        Matrix4f matrix = poseStack.method_23760().method_23761();

        double x1 = minX - camPos.field_1352, y1 = minY - camPos.field_1351, z1 = minZ - camPos.field_1350;
        double x2 = maxX - camPos.field_1352, y2 = maxY - camPos.field_1351, z2 = maxZ - camPos.field_1350;

        // bottom square
        edge(consumer, matrix, x1, y1, z1, x2, y1, z1, r, g, b, a);
        edge(consumer, matrix, x2, y1, z1, x2, y1, z2, r, g, b, a);
        edge(consumer, matrix, x2, y1, z2, x1, y1, z2, r, g, b, a);
        edge(consumer, matrix, x1, y1, z2, x1, y1, z1, r, g, b, a);
        // top square
        edge(consumer, matrix, x1, y2, z1, x2, y2, z1, r, g, b, a);
        edge(consumer, matrix, x2, y2, z1, x2, y2, z2, r, g, b, a);
        edge(consumer, matrix, x2, y2, z2, x1, y2, z2, r, g, b, a);
        edge(consumer, matrix, x1, y2, z2, x1, y2, z1, r, g, b, a);
        // verticals
        edge(consumer, matrix, x1, y1, z1, x1, y2, z1, r, g, b, a);
        edge(consumer, matrix, x2, y1, z1, x2, y2, z1, r, g, b, a);
        edge(consumer, matrix, x2, y1, z2, x2, y2, z2, r, g, b, a);
        edge(consumer, matrix, x1, y1, z2, x1, y2, z2, r, g, b, a);
    }

    /**
     * Same box via a plain AABB (already camera-relative or world-space with
     * camPos subtracted). Uses the vanilla box renderer for a 1-block cube.
     */
    public static void drawBox(class_4587 poseStack, class_4597 bufferSource, class_243 camPos,
                               double x, double y, double z, float r, float g, float b, float a) {
        class_243 p = class_243.method_24954(class_2338.method_49637(x, y, z)).method_1020(camPos);
        class_238 box = new class_238(p.field_1352, p.field_1351, p.field_1350, p.field_1352 + 1, p.field_1351 + 1, p.field_1350 + 1);
        class_761.method_22982(poseStack, bufferSource.getBuffer(class_1921.method_23594()),
                box, (int) (r * 255), (int) (g * 255), (int) (b * 255), (int) (a * 255));
    }

    /** Draws a single line segment from (x1,y1,z1) to (x2,y2,z2), camera-relative. */
    public static void line(class_4587 poseStack, class_4597 bufferSource, class_243 camPos,
                            double x1, double y1, double z1,
                            double x2, double y2, double z2,
                            float r, float g, float b, float a) {
        class_4588 consumer = bufferSource.getBuffer(class_1921.method_23594());
        Matrix4f matrix = poseStack.method_23760().method_23761();
        edge(consumer, matrix, x1 - camPos.field_1352, y1 - camPos.field_1351, z1 - camPos.field_1350,
                x2 - camPos.field_1352, y2 - camPos.field_1351, z2 - camPos.field_1350, r, g, b, a);
    }

    /**
     * True when no full-cube block sits between the player's eye and the
     * given point — used so combat assists never attack through solid walls.
     */
    public static boolean hasLineOfSight(class_310 client, double tx, double ty, double tz) {
        if (client == null || client.field_1724 == null || client.field_1687 == null) return false;
        class_243 eye = client.field_1724.method_33571();
        double dx = tx - eye.field_1352;
        double dy = ty - eye.field_1351;
        double dz = tz - eye.field_1350;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < 0.2) return true;
        double steps = Math.max(1.0, Math.ceil(dist / 0.25));
        for (int i = 1; i < steps; i++) {
            double t = i / steps;
            class_2338 pos = class_2338.method_49637(eye.field_1352 + dx * t, eye.field_1351 + dy * t, eye.field_1350 + dz * t);
            if (client.field_1687.method_8320(pos).method_26216(client.field_1687, pos)) {
                return false;
            }
        }
        return true;
    }

    private static void edge(class_4588 consumer, Matrix4f matrix,
                             double x1, double y1, double z1,
                             double x2, double y2, double z2,
                             float r, float g, float b, float a) {
        consumer.method_22918(matrix, (float) x1, (float) y1, (float) z1).method_22915(r, g, b, a);
        consumer.method_22918(matrix, (float) x2, (float) y2, (float) z2).method_22915(r, g, b, a);
    }
}
